<?php
class Home extends CI_Controller {

    /**
    * Check if the user is logged in, if he's not, 
    * send him to the login page
    * @return void
    */
	public function __construct()
    {
        parent::__construct();
		
		$this->load->model('user_model');
		 $this->load->helper('url');
		
        if(!$this->session->userdata('is_logged_in')){
            //redirect('admin/login');
        }
    }
	function index()
	{
		$this->load->helper('url');
		$data['main_content'] = 'home_view';
		//echo print_r($this->session->flashdata()); die;
        $this->load->view('includes/template', $data); 
	}
	function confirm(){
			$email_encode = $this->uri->segment(3);
			if(!empty($email_encode)){
				$email = base64url_decode($email_encode);
				$pass = generate_password();
				
                $data_to_store = array(
                   	'password' => md5($pass),
					'account_confirmed' => 'YES',
					'status' => 'Active'
			    );
					
				 	$this->load->helper('email');
    				//load email library
    				$this->load->library('email');
    
    				//read parameters from $_POST using input class
    				 // check is email addrress valid or no
						if (valid_email($email)){  
						  // compose email
						  $get_admin_detail = get_admin_detail(); //common helper function for admin detail
						  $this->email->from($get_admin_detail['email'] , $get_admin_detail['name']);
						  $this->email->to($email); 
						  $this->email->set_mailtype("html");
						  $this->email->subject('Register confirmation and password for KnewDog!');
						  /*$message = '<style>p{margin-bottom:2px;}</style>
						  			<p>Your Password : '.$pass.'</p>
									<p>Thanks,<br/>KnewDog Team.</p>';*/
							$users = $this->user_model->get_user_by_filed('primary_email',$email);
						  	$mail_data['password'] = $pass;
							$mail_data['username'] = $users[0]['username'];
							$message = $this->load->view('mail_templates/password_mail', $mail_data,true); 
						  	$this->email->message($message);  
						  
						  // try send mail ant if not able print debug
						  if ( ! $this->email->send())
						  {
							$msgadd = "<strong>E-mail not sent </strong>";//.$this->email->print_debugger();  
							 $data['flash_message'] = TRUE;
							$this->session->set_flashdata('flash_class','alert-error');
									$this->session->set_flashdata('flash_message', $msgadd);
								redirect('signup');    
						  }else{
							
							  if($this->user_model->update_user_by_email($email,$data_to_store)){
									$data['flash_message'] = TRUE;
									$this->session->set_flashdata('flash_class','alert-success');
									$this->session->set_flashdata('flash_message', '<strong>Well done!</strong> You have Sign up with Success.');
									redirect('signup');
									 //redirect('admin/user'.'');
								}else {
									$data['flash_message'] = TRUE;
									$this->session->set_flashdata('flash_class','alert-error');
									$this->session->set_flashdata('flash_message', '<strong>Oh snap!</strong> change a few things up and try submitting again.');
								redirect('signup'); 
									
									}
							  
							  }
						}
			}
		$data['main_content'] = 'reset_password_view';
        $this->load->view('includes/template', $data); 
		}
    /**
    * encript the password 
    * @return mixed
    */	
   public function facebook_login(){
	   $data['main_content'] = 'home_view';
		//facebook add user and session entry process end
				$this->load->library('facebook');
				$user = $this->facebook->getUser();
			if(!empty($user)){
       			//echo '<pre>';print_r($user);
	   			$data['user_profile'] = $this->facebook->api('/me');
				//echo print_r($data['user_profile']);
				$access_token = $this->facebook->getAccessToken();
				$params = array('next' => base_url('welcome/logout/'), 'access_token' => $access_token);
				$data['logout_url'] = $this->facebook->getLogoutUrl($params);
				//echo '<pre>'; print_r($data);
				$get_users = $this->user_model->get_user_by_filed('fb_id',$data['user_profile']['id']);
				//echo '<pre>';print_r($get_users);
				//$mail_data['username'] = $users[0]['fb_id'];
				$user_rand_id = $this->functions->get_user_rand_id();
			if(count($get_users) == 0){
					 $data_to_store = array(
					 	'user_rand_id' => $user_rand_id,
						'firstname' => $data['user_profile']['first_name'],//$this->input->post('firstname'),
						'fb_id' => $data['user_profile']['id'],
						'lastname' => $data['user_profile']['last_name'],//$this->input->post('lastname'),
						'username' => $data['user_profile']['username'],//$this->input->post('username'),
						'password' => '',//$this->__encrip_password($this->input->post('password')),
						'primary_email' => $data['user_profile']['email'],
						'gender' => $data['user_profile']['gender'],
						'avatar' => '',//$file_name,
						'town' => '',//$this->input->post('town'),
						'type_of_membership' => 'FREE',//$this->input->post('type_of_membership'),
						'date_of_registration' => date("Y-m-d H:i:s"),
						'last_login' => date("Y-m-d H:i:s"),
						'zip_code' => '',//$this->input->post('zip_code'),
						'country_code' => '', //$this->input->post('country_code'),
						'user_interests' => '',//$this->input->post('user_interests'),
						'additional_email1' => '',//$this->input->post('additional_email1'),
						'additional_email2' => '',//$this->input->post('additional_email2'),
						'no_ads' => '',//$this->input->post('no_ads'),
						'adult_content' => '',//$this->input->post('adult_content'),
						'privacy_settings' => '',//$this->input->post('privacy_settings'),
						'primary_email_2' => '',//$this->input->post('primary_email_2'),
						'i_firstname' => '',//$this->input->post('i_firstname'),
						'i_lastname' => '',//$this->input->post('i_lastname'),
						'i_company_name' => '',//$this->input->post('i_company_name'),
						'i_town' => '',//$this->input->post('i_town'),
						'i_zip_code' => '',//$this->input->post('i_zip_code'),
						'i_country' => '',//$this->input->post('i_country'),
						'account_confirmed' => 'YES',
						'status' => 'Active',//$this->input->post('status')
					);
					$this->user_model->store_user($data_to_store);
				}else{
					$data_to_store = array(
						'firstname' => $data['user_profile']['first_name'],//$this->input->post('firstname'),
						'lastname' => $data['user_profile']['last_name'],//$this->input->post('lastname'),
						'username' => $data['user_profile']['username'],//$this->input->post('username'),
						'primary_email' => $data['user_profile']['email'],
						'gender' => $data['user_profile']['gender'],
						'last_login' => date("Y-m-d H:i:s"),	
					);
					$this->user_model->update_user_by_field('fb_id',$get_users[0]['fb_id'],$data_to_store);
					
					}
					$session = array(
					'username' => $get_users[0]['username'],
					'user_id' => $get_users[0]['user_id'],
					'type_of_membership' => $get_users[0]['type_of_membership'],
					'is_logged_in' => true
				);
				$this->session->set_userdata($session);
			//facebook add user and session entry process end
			//redirect(site_url());
				$this->load->view('includes/template', $data); 
			}
			
        $this->load->view('includes/template', $data); 
	   
	   }
	   public function logout(){
			//check facebook login for logout
			$url = $this->session->flashdata('redirect_url');
			$this->load->helper('url');
			$this->load->library('facebook');
			//setcookie('fbs_'.$this->facebook->getAppId(), '', time()-100, '/', site_url());
			//echo '<pre>';print_r($this->session->userdata);die;
			$reuired_sessiondata = array(
					'session_id' => $this->session->userdata('session_id'),
					'ip_address' => $this->session->userdata('ip_address'),
					'user_agent' => $this->session->userdata('user_agent'),
					'last_activity' => $this->session->userdata('last_activity'),
					'language_shortcode' => $this->session->userdata('language_shortcode'),
				);
			$this->facebook->destroySession();
			$array_items = array('username' => '', 'user_id' => '','type_of_membership' => '', 'is_logged_in' => false);
			$this->session->unset_userdata($array_items);
			$this->session->sess_destroy();
			//set session required
			$this->session->set_userdata($reuired_sessiondata);
			redirect($url);
			
			//$data['main_content'] = 'home_view';
			//$this->load->view('includes/template', $data);
		}

}