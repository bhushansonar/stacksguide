<main>
<link href="<?php echo site_url('assets/css')?>/rateit.css" rel="stylesheet" type="text/css">
<div class="set_errors">

<?php 
 echo validation_errors();
     if($this->session->flashdata('flash_message')){
          echo '<div class="alert '.$this->session->flashdata("flash_class").'">';
            echo '<a class="close" data-dismiss="alert">&#215;</a>';
            echo $this->session->flashdata("flash_message");
          echo '</div>';       
      }
	  //echo '<pre>'; print_r($newsletter); die;
	  ?>
</div>
      <section class="knewdog findnewsletter" id="container">
            <section id="knewdog_leftbar">
            	<div class="knewdog_leftbar_inner">
                    <div id="tabsholder">
                        <ul class="tabs">
                            <li class="current" id="tab1" style="">Find<br/>Newsletters</li>
                            <li class="" id="tab2">My<br/>Newsletters</li>
                        </ul>
                    </div>
                       <section>

                            
                            <article class="reviewlist">
                                <div class="dashreview fullwidth_left">
                                    <div class="review_img">
                                    <a href="#">
                                 <?php if(!empty($newsletter[0]['screenshot'])){?>
                                    <img src="<?php echo base_url(); ?>uploads/<?php echo $newsletter[0]['screenshot'];?>">
                                    <?php }else{?>
                                    <img style="width:166; height:170px;" src="<?php echo base_url(); ?>assets/img/authornewsletter.png">
                                    <?php }?>
                                    </a></div>
                                    <div class="review_detail specific_review_detail">
                                    <a class="name" href="#"><?php echo $newsletter[0]['newsletter_name']?></a><br/>
                                    <div class="subscription"><?php echo $newsletter[0]['headline'];?></div>
                                    <div class="subscriptiondetail specific_subscriptiondetail">
                                    <label style="color:#808080;">by: </label><?php echo $newsletter[0]['author_name']?>
                                   <?php
								    $get_rate = $this->newsletter_model->get_rate_by_user($newsletter[0]['newsletter_id']);
									include("rating/rating_calculation.php");
									
									$user_id = $this->session->userdata("user_id"); 
									//echo "user_id->".$newsletter[$i]["user_id"];
									$wherefield =array("join_newsletter_id");
									$wherevalue = array($newsletter[0]["newsletter_id"]);
									$get_news_user_id = $this->newsletter_model->get_rate_by_field($wherefield,$wherevalue);
								/*if(!empty($user_id)){
									if(count($get_news_user_id) > 0){
											$readonly = "true";		
								    }else{
										$readonly = "false";	
										}
								}else{
										$readonly = "true";
									}*/
									$readonly = "true";
									//echo '<pre>'; print_r($get_news_user_id);
									//$data['get_rate'] = $get_rate;	
										?>
                                     <span class="rating_hover">
                                    <div title="<?php echo $avg_round;?>" style="margin-left: 20px; display: inline-block; vertical-align: text-bottom;" data-productid="<?php echo $newsletter[0]['newsletter_id']; ?>" data-rateit-resetable="false" data-rateit-value="<?php echo $avg_round;?>" data-rateit-ispreset="true" data-rateit-reset="false" data-rateit-readonly="<?php echo $readonly?>" class="rateit" id="rateit9"></div>
									
									 <?php if(count($get_news_user_id) > 0){ ?>
                                    <img style="margin-left: 5px; vertical-align: text-top; display: inline-block;" src="<?php echo base_url(); ?>assets/img/review_down.png">
                                    <?php }?>
                                    <a style="text-decoration: none; margin-left: 3px; display: inline-block; vertical-align: top;" href="<?php echo site_url("newsletter/display-rate"."/".$newsletter[0]['newsletter_id']);?>">(<?php echo (!empty($total_user_rate)) ? $total_user_rate : "0";?>)</a>
                                      <?php if(count($get_news_user_id) > 0){ ?>
                                    <div style="top:57px;" class="rating_popup">
                                    	<?php $popupcss = "style='float:none; width:100%;'";?>
                                    	<?php include("rating/rating_view.php");?>
                                        <a href="<?php echo site_url("newsletter/display-rate"."/".$newsletter[0]['newsletter_id']);?>">See all <?php echo (!empty($total_user_rate)) ? $total_user_rate : "0";?> customer reviews</a>
                                    </div>
                                    <?php }?>
                                    </span>
									
									<?php /*?><img style="margin-left:20px; margin-top:2px;" src="<?php echo base_url(); ?>assets/img/yelloreviews.png"><img src="<?php echo base_url(); ?>assets/img/yelloreviews.png">
                                    <img src="<?php echo base_url(); ?>assets/img/yelloreviews.png"><img src="<?php echo base_url(); ?>assets/img/yelloreviews.png">
                                    <img src="<?php echo base_url(); ?>assets/img/yelloreviews.png"><img style="margin-left:5px;" src="<?php echo base_url(); ?>assets/img/review_down.png">
                                    <a style="text-decoration:none; margin-left:3px;" href="#">(64)</a><?php */?>
                                    <br/>
									<label style="color:#808080; margin-top:10px; float:left; width:100%;">698 subscribers<br/>
                                        4 newsletters last month<br/>
                                        frequency: <?php echo !empty($newsletter[0]['frequency']) ? $newsletter[0]['frequency'] : "N/A";?><br/>
                                        language: <?php echo !empty($newsletter[0]['language_longform']) ? $newsletter[0]['language_longform'] : "N/A";?><br/>
                                        latest edition: 2013-10-30<br/>
                                    </label> 
                                    </div>  
                                    <div class="review_subscribe"><a href="#"><img src="<?php echo base_url(); ?>assets/img/subscribe_specificpage.png"></a></div>
                                    </div>
                                </div>
                            </article>
                            
                            <article>
                            	<div class="fullwidth_left details">
                                <div class="title">Details:</div>
                                <div><label>Category:</label><?php echo str_replace(",",", ",($newsletter[0]['g_en']));?></div>
                                <div><label>Keywords: </label>
                                <?php echo (!empty($newsletter[0]['g_keyword_name']) ? str_replace(",",", ",($newsletter[0]['g_keyword_name'])) : "N/A");?></div>
                                <div><label>Publisher:</label><a href="<?php echo $newsletter[0]['website_url']?>"><?php echo $newsletter[0]['website_url']?></a></div>
                                <div><label>Location:</label><?php echo !empty($newsletter[0]['country_name']) ? $newsletter[0]['country_name'] : "N/A"; ?></div>
                                <!--<div style="margin-bottom:5px;" class="control-group">
                                    <label style="float: left;width: 140px;padding-top: 5px;text-align: right;margin: 0 20px 0 12px;" for="inputError" class="control-label">ID</label>
                                    <div style="margin-left: 60px;px;" class="controls">
                                        <div style="margin-top:5px;">APR1412172N</div>
                                    </div>
                                  </div>-->
                                </div>
                            </article>
                            
                            <article>
                            	<div class="fullwidth_left description">
                                <div class="title">Description:</div>
                                <?php echo !empty($newsletter[0]['description']) ? $newsletter[0]['description'] : "No Description found!" ?>
                                <!--The sole mission of Military in Transition Training Institute, LLC (MITTI-USA.com) is to serve the educational needs of veterans, spouses of 
                                veterans and spouses of military personnel presently serving in the armed forces. We offer an on-line Personal Care Aide training program that is
                                affordable and comprehensive. Our program is designed to make graduates ‘job-ready’ in a short period of time and to promote their transition from
                                military service to meaningful and purposeful civilian employment. affordable and comprehensive. Our program is designed to make graduates
                                'job-ready’ in a short period of time and to promote their transition from military service to meaningful and purposeful civilian employment.-->
                                </div>
                            </article>
                            
                            <article class="videos">
                           	 	<div class="fullwidth_left">
                               <?php
							    if(!empty($newsletter[0]['video'])){
									$videos = explode("@@@",$newsletter[0]['video']);
									for($v=0;$v<count($videos);$v++){
										$link = get_youtube_code($videos[$v]);
										if(($v%2) == 0){ $class = "video1";}else{$class= "video2";}
									?>
                                    <div class="<?php echo $class;?>">
                                    <iframe width="278" height="189" src="http://www.youtube.com/embed/<?php echo $link?>"></iframe>
                                    </div>
							<?php	}
								}else{ ?>
                                <p style="text-align:center; font-size:14px;">Video not available!</p>
                                <?php }?>
                                   <!-- <div class="video2">
                                    <img src="<?php //echo base_url(); ?>assets/img/video2.png">
                                    <div class="title">Lorem ipsum dolor sit amet</div>
                                    </div>-->
                                </div>
                            </article>
                            
                            <article>
                            	<div class="fullwidth_left description">
                                <div class="title">About the author:</div>
                                <?php echo !empty($newsletter[0]['about_author']) ? $newsletter[0]['about_author'] : "NO content found!"; ?>
                                <!--The sole mission of Military in Transition Training Institute, LLC (MITTI-USA.com) is to serve the educational needs of veterans, spouses of 
                                veterans and spouses of military personnel presently serving in the armed forces. We offer an on-line Personal Care Aide training program that is
                                affordable and comprehensive. Our program is designed to make graduates ‘job-ready’ in a short period of time and to promote their transition from
                                military service to meaningful and purposeful civilian employment. affordable and comprehensive. Our program is designed to make graduates
                                'job-ready’ in a short period of time and to promote their transition from military service to meaningful and purposeful civilian employment.-->
                                </div>
                            </article> 
                            
                            <article>
                            	<div class="fullwidth_left details">
                                    <div class="title">Newsletter Archive:</div>
                                    <div class="datte_time">
                                        <date><a href="#">2013-10-30</a></date>
                                        <date><a href="#">2013-09-28</a></date>
                                        <date><a href="#">2013-08-31</a></date>
                                        <date><a href="#">2013-07-31</a></date>
                                        <date><a href="#">2013-06-29</a></date>
                                        <date><a href="#">2013-05-30</a></date>
                                        <a class="datelink" href="#">more...<img src="<?php echo base_url(); ?>assets/img/more.png"></a>
                                    </div>
                                    <div class="review_subscribe"><a href="#"><img src="<?php echo base_url(); ?>assets/img/subscribe_specificpage.png"></a></div>
                                </div>
                            </article>
                            <article>
                            	<div class="fullwidth_left details userrating">
                                    <div class="title">User Rating:</div>
                                   <?php 
								  
									/*$total_user_rate = count($get_rate);
									$star_1 = array();
									$star_2 = array();
									$star_3 = array();
									$star_4 = array();
									$star_5 = array();
									$avg_rate = array();
									//echo '<pre>'; print_r($get_rate);
									for($r=0;$r<count($get_rate);$r++){
											$avg_rate[] = $get_rate[$r]['rate'];
											
											if($get_rate[$r]['rate'] <= 1)
											{
												$star_1[] = $get_rate[$r]["rate"];
											}
											else if($get_rate[$r]['rate'] <= 2)
											{
												$star_2[] = $get_rate[$r]["rate"];
											}
											else if($get_rate[$r]['rate'] <= 3)
											{
												$star_3[] = $get_rate[$r]["rate"];
											}
											else if($get_rate[$r]['rate'] <= 4)
											{
												$star_4[] = $get_rate[$r]["rate"];
											}
											else if($get_rate[$r]['rate'] <= 5)
											{
												$star_5[] = $get_rate[$r]["rate"];
											}										
										}
										//echo '<pre>';print_r($avg_rate);
										$s_star_1 = 	count($star_1);
										@$s_star_1_per = (100 * $s_star_1)/$total_user_rate;
										$s_star_1_per = !empty($s_star_1_per) ? $s_star_1_per : "0";
										
										$s_star_2 = 	count($star_2);
										@$s_star_2_per = (100 * $s_star_2)/$total_user_rate;
										$s_star_2_per = !empty($s_star_2_per) ? $s_star_2_per : "0";
										
										$s_star_3 = 	count($star_3);
										@$s_star_3_per = (100 * $s_star_3)/$total_user_rate;
										$s_star_3_per = !empty($s_star_3_per) ? $s_star_3_per : "0";
										
										$s_star_4 = 	count($star_4);
										@$s_star_4_per = (100 * $s_star_4)/$total_user_rate;
										$s_star_4_per = !empty($s_star_4_per) ? $s_star_4_per : "0";
										
										$s_star_5 = 	count($star_5);
										@$s_star_5_per = (100 * $s_star_5)/$total_user_rate;
										$s_star_5_per = !empty($s_star_5_per) ? $s_star_5_per : "0";
										
										$s_star_1_per = round($s_star_1_per,2);
										$s_star_2_per = round($s_star_2_per,2);
										$s_star_3_per = round($s_star_3_per,2);
										$s_star_4_per = round($s_star_4_per,2);
										$s_star_5_per = round($s_star_5_per,2);
										//echo '<pre>';print_r($avg_rate);
										@$rate_sum = array_sum($avg_rate);
										@$avg = (float)$rate_sum/(int)$total_user_rate;
										@$avg_round = $avg;//round(2.8, 1);*/
									include("rating/rating_calculation.php");
									$popupcss = "";
								   include("rating/rating_view.php");?>
                                    <div class="starrating_detail">
                                        <div class="reviewstar">
                                            <div title="<?php echo $avg_round;?>" style="float:left;margin-top:2px;" data-productid="<?php echo $newsletter[0]['newsletter_id']; ?>" data-rateit-resetable="false" data-rateit-value="<?php echo $avg_round;?>" data-rateit-ispreset="true" data-rateit-reset="false" data-rateit-readonly="true" class="rateit" id="rateit9"></div>
                                            <a style="margin-left:3px;" href="<?php echo site_url("newsletter/display-rate"."/".$newsletter[0]['newsletter_id']);?>">(<?php echo $total_user_rate;?>)</a>
                                        </div>
                                        <div class="reviewstar"><div style="color:#808080; margin-top:5px;"><?php echo round($avg_round,2)?> Out of 5 stars</div></div>
                                        <div class="reviewstar"><div style="margin-top:5px;"><a href="<?php echo site_url("newsletter/display-rate")."/".$newsletter[0]["newsletter_id"];?>">See all <?php echo $total_user_rate;?> customer reviews</a></div></div>
                                    </div>
                                </div>
                            </article> 
                            <article>
                            	 <div style="font-size:14px;" class="title">Most Recent Reviews:</div>
                          <?php if(count($newsletter_review) > 0){
								for($n=0;$n<count($newsletter_review);$n++){
									?>
                            	<div class="fullwidth_left details mostrecentreviews">
                                   
                                        <div class="minititle">
                                            <div title="<?php echo $newsletter_review[$n]['rate'];?>" style="float:left;" data-productid="<?php echo $newsletter_review[$n]['join_newsletter_id']; ?>" data-rateit-resetable="false" data-rateit-value="<?php echo $newsletter_review[$n]['rate'];?>" data-rateit-ispreset="true" data-rateit-reset="false" data-rateit-readonly="true" class="rateit" id="rateit9"></div>
                                            <label><?php echo $newsletter_review[$n]["title"]?></label>
                                        </div>
                                        <div class="description"><?php echo $newsletter_review[$n]["message"]?></div>
                                        <span>Published on <?php echo @date('j, F Y',strtotime($newsletter_review[$n]['date']));?> by <?php echo $newsletter_review[$n]["firstname"]?></span>
                                </div>
                               <?php }
							   }?>
                                <?php /*?><?php echo '<pre>'; print_r($newsletter_review);
								echo '</pre>';?>
                                <div class="fullwidth_left details mostrecentreviews">
                                        <div class="minititle">
                                            <img src="<?php echo base_url(); ?>assets/img/yellowbgigstar.png"><img src="<?php echo base_url(); ?>assets/img/yellowbgigstar.png">
                                            <img src="<?php echo base_url(); ?>assets/img/whitebigstar.png"><img src="<?php echo base_url(); ?>assets/img/whitebigstar.png"><img src="<?php echo base_url(); ?>assets/img/whitebigstar.png">
                                            <label>Very weak science</label>
                                        </div>
                                        <div class="description">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut<br/>
                                        labore et dolore magna aliqua. Ut enim ad minim veniam...<a href="#">Read more</a></div>
                                        <span>Published 1 month ago by Sergio A. Rosales</span>
                                </div><?php */?>
                            </article>
                	</section>
                </div>

            </section>
            <script type="text/javascript">
            $(document).ready(
    		function(){
			 $(".rating_hover").hover(function(e){
				 if ( $(this).children(".rating_popup").is(":visible")==true) {
						$(this).children(".rating_popup").hide();
					}
					else {
						$(this).children(".rating_popup").show();
					}       
				 //$(this).next().css("display","block");
				 }
			 );
			   });
            </script>
            <?php include_once("includes/sidebars/newsletter_sidebar.php");?>
            <script src="<?php echo site_url('assets/js')?>/jquery.rateit.js" type="text/javascript"></script>
        </section>
</main>