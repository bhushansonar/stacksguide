    <div class="container top">
      
      <ul class="breadcrumb">
        <li>
          <a href="<?php echo site_url("admin"); ?>">
            <?php echo ucfirst($this->uri->segment(1));?>
          </a> 
          <span class="divider">/</span>
        </li>
        <li>
            <?php echo ucfirst($this->uri->segment(2));?>
         </ul>
      
      <div class="page-header">
        <h2>
        <?php echo ucfirst($this->uri->segment(2));?>
        </h2>
        <h3 style="margin-top:5px;">Welcome <a href="<?php echo base_url();?>admin/user/update/<?php echo $this->session->userdata['user_id'] ?>"><?php echo $this->session->userdata['username'];?></a> to KnewDog Admin.</h3>
      </div>
	     <div class="quickLink"> 
         <a href="<?php echo base_url(); ?>admin/category" title="Category">
         	<img alt="Add Category" src="<?php echo base_url(); ?>/assets/img/admin/ico/categoryico.png" />
            	<span>Newsletter Category</span>
             </a>
        </div>
        <div class="quickLink"> 
         <a href="<?php echo base_url(); ?>admin/keyword" title="Keyword">
         	<img alt="Add Keyword" src="<?php echo base_url(); ?>/assets/img/admin/ico/keyword.png" />
            	<span>Newsletter Keyword</span>
             </a>
        </div>
        <div class="quickLink"> 
         <a href="<?php echo base_url(); ?>admin/language" title="Language">
         	<img alt="Add Language" src="<?php echo base_url(); ?>/assets/img/admin/ico/language.png" />
            	<span>Newsletter Language</span>
             </a>
        </div>
        <div class="quickLink"> 
         <a href="<?php echo base_url(); ?>admin/newsletter" title="News Letter">
         	<img alt="Add Category" src="<?php echo base_url(); ?>/assets/img/admin/ico/newsletter.png" />
            	<span>Newsletter Library</span>
             </a>
        </div>
        <div class="quickLink"> 
         <a href="<?php echo base_url(); ?>admin/sitelanguage" title="Site Language">
         	<img alt="Add Site Language" src="<?php echo base_url(); ?>/assets/img/admin/ico/language.png" />
            	<span>Site Language</span>
             </a>
        </div>
        <div class="quickLink"> 
         <a href="<?php echo base_url(); ?>admin/languagekeyword" title="Language Keyword">
         	<img alt="Add Language Keyword" src="<?php echo base_url(); ?>/assets/img/admin/ico/keyword.png" />
            	<span>Language Database</span>
             </a>
        </div>
        <div class="quickLink"> 
         <a href="<?php echo base_url(); ?>admin/advertisement" title="Advertisement">
         	<img alt="Add Advertisement" src="<?php echo base_url(); ?>/assets/img/admin/ico/advertisement.png" />
            	<span>Email advertisement</span>
             </a>
        </div>
        <div class="quickLink"> 
         <a href="<?php echo base_url(); ?>admin/wanted-add" title="Wanted add">
         	<img alt="Add Wanted add" src="<?php echo base_url(); ?>/assets/img/admin/ico/advertisement.png" />
            	<span>Website advertisement</span>
             </a>
        </div>
        
        <div class="quickLink"> 
         <a href="<?php echo base_url(); ?>admin/cms" title="CMS">
         	<img alt="Add CMS" src="<?php echo base_url(); ?>/assets/img/admin/ico/static_pageico.png" />
            	<span>CMS</span>
             </a>
        </div>
        <div class="quickLink"> 
         <a href="<?php echo base_url(); ?>admin/cpanel" title="Cpanel">
         	<img alt="Add Cpanel" src="<?php echo base_url(); ?>/assets/img/admin/ico/cpanel.png" />
            	<span>Cpanel</span>
             </a>
        </div>
        <div class="quickLink"> 
         <a href="<?php echo base_url(); ?>admin/user" title="User">
         	<img alt="Add User" src="<?php echo base_url(); ?>/assets/img/admin/ico/user.png" />
            	<span>Users</span>
             </a>
        </div>
    </div>
    <?php //echo '<pre>';print_r($this->session->userdata);?>
     