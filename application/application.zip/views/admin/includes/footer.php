	<div id="footer">
		<hr>
		<div class="inner">
			<div class="container">
				<p class="right"><a class="backtotop" href="#">Back to top</a></p>
				<p>
				</p>
			</div>
		</div>
	</div>
	
	<script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/js/admin.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/jquery.confirm.js"></script>
   <script src="<?php echo base_url(); ?>assets/js/custom.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/run_prettify1.js"></script>
    	
    
</body>
</html>