<?php $this->load->view('admin/includes/header'); ?>

<?php $this->load->view($main_content); ?>

<?php $this->load->view('admin/includes/footer'); ?>