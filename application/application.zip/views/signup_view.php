<main>
<div class="set_errors">
<?php 
 echo validation_errors();
	  //echo $this->session->flashdata('flash_message');
      if($this->session->flashdata('flash_message')){
       /* if($this->session->flashdata('flash_message') == 'add')
        {*/
          echo '<div class="alert '.$this->session->flashdata("flash_class").'">';
            echo '<a class="close" data-dismiss="alert">&#215;</a>';
            echo $this->session->flashdata("flash_message");
          echo '</div>';       
        /*}else if($this->session->flashdata('flash_message') == 'update'){
		 echo '<div class="alert alert-success">';
            echo '<a class="close" data-dismiss="alert">&#215;</a>';
            echo '<strong>Well done!</strong> user updated with success.';
          echo '</div>'; 
		}else if($this->session->flashdata('flash_message') == 'delete'){
		echo '<div class="alert alert-success">';
            echo '<a class="close" data-dismiss="alert">&#215;</a>';
            echo '<strong>Well done!</strong> user deleted with success.';
          echo '</div>';
		}else{
          echo '<div class="alert alert-error">';
            echo '<a class="close" data-dismiss="alert">&#215;</a>';
            echo '<strong>Oh snap!</strong> change a few things up and try submitting again.';
          echo '</div>';          
        }*/
      }?>
</div>
        <section id="signupfree">

				<section class="signupfree_container">
                       <?php /*?> <article style="margin:30px auto 17px 0px; width:100%; line-height:0; text-align:center;">
                        	<div style="font-size:190%; line-height:normal;" class="signupfree_blacktitle"><?php echo _clang(SIGNUP_TITLE1);?></div>
            			</article>
                        <article style="margin:30px auto 17px 0px; width:100%; line-height:0; text-align:center;">
                        	<div style="font-size:18px;" class="signupfree_blacktitle"><?php echo _clang(SIGNUP_NOW);?> <u><?php echo _clang(FOR_FREE);?> !</u></div>
            			</article><?php */?>
                        <?php echo cms_block('SIGNUP_HEAD')?>
                <br/>
                
                <section id="home_right">
                 <?php if(!$this->session->userdata('is_logged_in')){?>
                    <article>
                        <div class="topheader">
                            <ul>
                                <li class="signinwith"><?php echo _clang(SIGN_IN_WITH_SIGNUP);?></li>
                                <li class="facebook"><img src="<?php echo base_url(); ?>assets/img/facebook.png"><?php echo _clang(FACEBOOK)?></li>
                                <li class="google"><img src="<?php echo base_url(); ?>assets/img/google.png"><?php echo _clang(GOOGLE)?></li>
                            </ul>
                        </div>
                        <p class="quicksignup_home"><?php echo _clang(QUICK_SING_UP_SIGNUP);?>.</p>
                        <form method="post" class="form_home" action="<?php echo site_url('signup/create_member')?>">
                            <input class="username_home" name="username" type="text" placeholder="<?php echo _clang(USERNAME);?>">
                            <input class="emailaddress_home" name="email" type="text" placeholder="<?php echo _clang(YOUR_EMAIL_ADD);?>"><br/>
                            <input class="signup_btn1" value="Sign Up Now!" name="Submit" type="submit" />
                        </form>
                        <p class="freeaccount quicksignup_home"><?php echo _clang(ITS_FREE)?> !</p>
                        <span style="color:#808080; border-bottom:1px solid #BB753E; float: left; width: 100%; padding-bottom: 20px; font-size:15px; margin-top:23px;">
                            <?php echo _clang(BY_CLICKING);?>
                        </span>
                    </article>
                      <?php }?>
                </section>
              
                
               <?php /*?> <section id="howdoesitwork">
                    <article>
                    <div class="signupfree_blacktitle howdoesitwork_title"><h2><?php echo _clang(HOW_DOES)?> ?</h2></div>
                        <div class="dash_jwl_one_fourth">
                            <div class="jwl_one_fourth"><img height="113" width="113" src="<?php echo base_url(); ?>assets/img/pictogram1.png" class="alignnone size-full wp-image-257">
                            <?php echo _clang(SIGNUP_WITH_YOUR);?>
                            </div>
                            <div class="jwl_one_fourth"><img height="113" width="113" src="<?php echo base_url(); ?>assets/img/pictogram2.png" class="alignnone size-full wp-image-257">
                            <?php echo _clang(BROWSE_OUR);?>
                            </div>
                            <div class="jwl_one_fourth"><img height="113" width="113" src="<?php echo base_url(); ?>assets/img/pictogram3.png" class="alignnone size-full wp-image-257">
                            <?php echo _clang(READ_THE_NEWSLETTERS);?>
                            </div>
                            <div class="jwl_one_fourth last"><img height="113" width="113" src="<?php echo base_url(); ?>assets/img/pictogram4.png" class="alignnone size-full wp-image-257">
                            <?php echo _clang(DID_NOT_FIND);?>
                            </div>
                        </div>
                        <div class="clearboth"></div>
                        <p style="margin-bottom: 1.5em;"></p>
                        <h3><span style="color: #e46c0a; font-size:16px;"><?php echo _clang(OUR_PROMISE);?></span></h3>
                        <hr>
                    </article>
                </section>
                
                <section id="newfeaturestobecomingup">
                    <article>
                        <div class="signupfree_blacktitle newfeaturestobecomingup_title"><h2><?php echo _clang(NEW_FEATURES)?></h2></div>
                        <ul class="newfeaturestobecomingup">
                            <li><?php echo _clang(GET_ALL_YOUR);?></li>
                            <li><?php echo _clang(CHOOSE_DATE);?></li>
                            <li><?php echo _clang(SELECT_INDIVIDUAL);?></li>
                            <li><?php echo _clang(THE_FEEDBACK);?></li>
                            <li><?php echo _clang(QUICK_AND_EASY);?></li>
                            <li><?php echo _clang(COMPANY_ACCOUNTS);?></li>
                        </ul>
                        <hr>
                    </article>
                </section><?php */?>
                <?php echo cms_block('SIGNUP_HOW_DOES');?>
                
				<section class="signupfree_container" style="float:left;">
                        <?php /*?><article style="margin:30px auto 17px 0px; width:100%; line-height:0; text-align:center;">
                        	<div style="font-size:190%; line-height:normal;" class="signupfree_blacktitle"><?php echo _clang(SIGNUP_TITLE1);?></div>
            			</article>
                        <article style="margin:30px auto 17px 0px; width:100%; line-height:0; text-align:center;">
                        	<div style="font-size:18px;" class="signupfree_blacktitle"><?php echo _clang(SIGNUP_NOW);?> <u><?php echo _clang(FOR_FREE);?> !</u></div>
            			</article><?php */?>
					<?php echo cms_block('SIGNUP_BOT');?>
                <br/>
                <section id="home_right">
                <?php if(!$this->session->userdata('is_logged_in')){?>
                    <article>
                        <div class="topheader">
                            <ul>
                                <li class="signinwith"><?php echo _clang(SIGN_IN_WITH_SIGNUP);?></li>
                                <li class="facebook"><img src="<?php echo base_url(); ?>assets/img/facebook.png"><?php echo _clang(FACEBOOK)?></li>
                                <li class="google"><img src="<?php echo base_url(); ?>assets/img/google.png"><?php echo _clang(GOOGLE)?></li>
                            </ul>
                        </div>
                        <p class="quicksignup_home"><?php echo _clang(QUICK_SING_UP_SIGNUP);?>.</p>
                        <form class="form_home">
                            <input class="username_home" name="" type="text" placeholder="<?php echo _clang(USERNAME);?>">
                            <input class="emailaddress_home" name="" type="text" placeholder="<?php echo _clang(YOUR_EMAIL_ADD);?>">
                            <input class="signup_btn" name="" type="button">
                        </form>
                        <p class="freeaccount quicksignup_home"><?php echo _clang(ITS_FREE)?> !</p>
                        <span style="color:#808080; float: left; width: 100%; padding-bottom: 20px; font-size:15px; margin-top:23px;">
                            <?php echo _clang(BY_CLICKING);?>
                        </span>
                    </article>
                    <?php }?>
                </section>
                
                
            	</section>
            
		</section>
        </section>
</main>