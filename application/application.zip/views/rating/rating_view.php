<?php !empty($popupcss) ? $popupcss : "";?>
<div <?php echo @$popupcss?>class="starrating">
                                        <table style="width:91%" border="0" align="left" cellspacing="1" cellpadding="0">
                                            <tbody><tr>
                                            <td align="left" style="padding-right:0.5em;padding-bottom:1px;white-space:nowrap;font-size:10px;">
                                              <a style="">5 star</a>
                                            </td>
                                            <td width="60" align="left" title="<?php echo $s_star_5_per?>%" class="rating_table" style="background-color: #F2F2F2;"><div style="background-color:#FFCC66; width:<?php echo $s_star_5_per;?>%;"></div></td>
                                            <td align="right" style="font-family:Verdana,Arial,Helvetica,Sans-serif;;font-size:13px; color:#808080;">&nbsp;<?php echo $s_star_5?></td>
                                            </tr>
                                            <tr>
                                            <td align="left" style="padding-right:0.5em;padding-bottom:1px;white-space:nowrap;font-size:10px;">
                                              <a style="" >4 star</a>
                                            </td>
                                            <td width="60" align="left" title="<?php echo $s_star_4_per?>%" class="rating_table" style="min-width:60; background-color: #F2F2F2"><div style="background-color:#FFCC66; width:<?php echo $s_star_4_per?>%;"></div></td>
                                            <td align="right" style="font-family:Verdana,Arial,Helvetica,Sans-serif;;font-size:13px; color:#808080;">&nbsp;<?php echo $s_star_4;?></td>
                                            </tr>
                                            <tr>
                                            <td align="left" style="padding-right:0.5em;padding-bottom:1px;white-space:nowrap;font-size:10px;">
                                              <a>3 star</a>
                                            </td>
                                            <td width="60" align="left" title="<?php echo $s_star_3_per?>%" class="rating_table" style="min-width:60; background-color: #F2F2F2"><div style="background-color:#FFCC66; width:<?php echo $s_star_3_per?>%;"></div></td>
                                            <td align="right" style="font-family:Verdana,Arial,Helvetica,Sans-serif;;font-size:13px; color:#808080;">&nbsp;<?php echo $s_star_3?></td>
                                            </tr>
                                            <tr>
                                            <td align="left" style="padding-right:0.5em;padding-bottom:1px;white-space:nowrap;font-size:10px;">
                                              <a>2 star</a>
                                            </td>
                                            <td width="60" align="left" title="<?php echo $s_star_2_per?>%" class="rating_table" style="min-width:60; background-color: #F2F2F2"><div style="background-color:#FFCC66; width:<?php echo $s_star_2_per?>%;"></div></td>
                                            <td align="right" style="font-family:Verdana,Arial,Helvetica,Sans-serif;;font-size:13px; color:#808080;">&nbsp;<?php echo $s_star_2;?></td>
                                            </tr>
                                            <tr>
                                            <td align="left" style="padding-right:0.5em;padding-bottom:1px;white-space:nowrap;font-size:10px;">
                                              <a>1 star</a>
                                            </td>
                                            <td width="60" align="left" title="<?php echo $s_star_1_per?>%" class="rating_table" style="min-width:60; background-color: #F2F2F2"><div style="background-color:#FFCC66; width:<?php echo $s_star_1_per?>%;"></div></td>
                                            <td align="right" style="font-family:Verdana,Arial,Helvetica,Sans-serif;;font-size:13px; color:#808080;">&nbsp;<?php echo $s_star_1?></td>
                                            </tr>
                                            <tr><td>&nbsp;</td><td><div style="width:60px;">&nbsp;</div></td><td>&nbsp;</td></tr>
                                            </tbody></table>
                                    </div>