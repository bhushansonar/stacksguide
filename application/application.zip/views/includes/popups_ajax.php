<?php
//echo $cls; die;
if($cls == 'subscribe_1')
{
	if(count($subscribe) == 0){
	$data = '<div class="popup_ajax subscribe_1">
	<form method="post" name="subscribe_1" id="subscribe_1" action="'.site_url('subscribe/add').'">
	<div class="subscribetonewsletters votebox">
    <div class="head_title">Subscribe to Newsletter:<label id="popup_nl_title">'.$newsletter[0]['newsletter_name'].'</label></div>
    <input type="hidden" id="s_newsletter_id" name="s_newsletter_id" value="'.$newsletter[0]['newsletter_id'].'" />
    <input type="hidden" id="s_user_id" name="s_user_id" value="'.$user_id.'" />
    <div class="title">Choose one of your schedules:</div>
	
	<div class="jumpmenu '.get_if_free_user('class_free_user').'"> 
		<div class="'.get_if_free_user('class_free_user_overlay_3').'" '.get_if_free_user('manage_schedule_popup_2').' ></div>
        <select name="schedule_id">';
		for($i=0;$i<count($schedule);$i++){
			$every = ($schedule[$i]['every']) ? "every ".$schedule[$i]['every'] ." Week": "";
			$week0 = ($schedule[$i]['weeks_on']) ? "on ".$schedule[$i]['weeks_on'] : "";
           $data .='<option value="'.$schedule[$i]['schedule_id'].'">'.$schedule[$i]['sending']." ".$every." ".$week0." at ". date("H.i", strtotime($schedule[$i]['at'] . ":00:00"))." to email ". $schedule[$i]['sending_to_email']."</option>";
		    }
        $data .='</select>
    </div>
    <div class="link_button">
		<div class="'.get_if_free_user('class_free_user_overlay_4').'" '.get_if_free_user('manage_schedule_popup_2').' ></div>
        <div class="left_link"><a href="#">Manage Schedules</a></div>
        <div class="right_button"><input style="margin-bottom: 5px; float: right; margin-top: 1px; padding-left: 18px; padding-right: 18px;" onclick="subcribe_1_submit(\'subscribe_1\');" class="btn btn_main" value="ok" name="Submit" type="button" /><a href="#" class="cancel popup_close">cancel</a></div>
    </div>
	</form>
	
</div>';
	}else{
		$data ='<div class="popup_ajax subscribe_1">
			<div class="subscription_compeleted votebox">
				<div class="gopremium_cancell_btn"><a class="popup_close" onclick="submitform(\'gotonl\')" href="javascript:void(0);"><img src="'.site_url('assets/img/cancel_white.png').'"></a></div>
				<div class="head_title">You are already subscribed to:</div>
				<div class="title">'.$newsletter[0]['newsletter_name'].'</div>
				<div class="content">
					We will send you this newslette according to your schedule as soon as
					its next issue becomes available in our database. Go to <a onclick="submitform(\'gotomynl\')" href="javascript:void(0);">My Newsletters.</a>
				</div>
			</div>
		</div><form method="post" id="gotomynl" action="'.site_url('newsletter').'">
			<input type="hidden" name="form" value="section_2"/>
		</form>
		<form method="post" id="gotonl" action="'.site_url('newsletter').'"></form>';
		}
} else if($cls == 'subscribe_1_edit')
{
	
	$data = '<div class="popup_ajax subscribe_1_edit">
	<form method="post" name="subscribe_1" id="subscribe_1" action="'.site_url('subscribe/edit').'">
	<div class="subscribetonewsletters votebox">
    <div class="head_title">Subscribe to Newsletter:<label id="popup_nl_title">'.$newsletter[0]['newsletter_name'].'</label></div>
    <input type="hidden" id="s_newsletter_id" name="s_newsletter_id" value="'.$newsletter[0]['newsletter_id'].'" />
    <input type="hidden" id="s_user_id" name="s_user_id" value="'.$user_id.'" />
    <div class="title">Choose one of your schedules:</div>
	
	<div class="jumpmenu '.get_if_free_user('class_free_user').'"> 
		<div class="'.get_if_free_user('class_free_user_overlay_3').'" '.get_if_free_user('manage_schedule_popup_2').' ></div>
        <select name="schedule_id">';
		for($i=0;$i<count($schedule);$i++){
			
			$every = ($schedule[$i]['every']) ? "every ".$schedule[$i]['every'] ." Week": "";
			$week0 = ($schedule[$i]['weeks_on']) ? "on ".$schedule[$i]['weeks_on'] : "";
			$selected_edit = ($schedule_id == $schedule[$i]['schedule_id']) ? "selected='selected'" : "";
           	
			$data .='<option '.$selected_edit.' value="'.$schedule[$i]['schedule_id'].'">'.$schedule[$i]['sending']." ".$every." ".$week0." at ". date("H.i", strtotime($schedule[$i]['at'] . ":00:00"))." to email ". $schedule[$i]['sending_to_email']."</option>";
		    }
        $data .='</select>
    </div>
    <div class="link_button">
		<div class="'.get_if_free_user('class_free_user_overlay_4').'" '.get_if_free_user('manage_schedule_popup_2').' ></div>
        <div class="left_link"><a href="#">Manage Schedules</a></div>
        <div class="right_button"><input style="margin-bottom: 5px; float: right; margin-top: 1px; padding-left: 18px; padding-right: 18px;" class="btn btn_main" value="ok" name="Submit" type="submit" /><a href="#" class="cancel popup_close">cancel</a></div>
    </div>
	</form>
	
</div>';
}elseif($cls == 'subscribe_success'){
	
$data	='<div class="popup_ajax subscribe_success">
			<div class="subscription_compeleted votebox">
				<div class="gopremium_cancell_btn"><a class="popup_close" onclick="submitform(\'gotonl\')" href="javascript:void(0);"><img src="'.site_url('assets/img/cancel_white.png').'"></a></div>
				<div class="head_title">Subscription compeleted. You are now subscribed to:</div>
				<div class="title">'.$newsletter[0]['newsletter_name'].'</div>
				<div class="content">
					We will send you this newslette according to your schedule as soon as
					its next issue becomes available in our database. Go to <a onclick="submitform(\'gotomynl\')" href="javascript:void(0);">My Newsletters.</a>
				</div>
			</div>
		</div>
		<form method="post" id="gotomynl" action="'.site_url('newsletter').'">
			<input type="hidden" name="form" value="section_2"/>
		</form>
		<form method="post" id="gotonl" action="'.site_url('newsletter').'"></form>';
	}else if($cls == 'schedule'){
		$data ='<div class="popup_ajax schedule">
					<div style="width:648px;" id="" class="freeusers_box signup_popup">
						<div class="popup_heading">Edit My Schedule</div>
		  					<div class="popup_cancle"><a style="opacity:1;" class="popup_close" href="#"><img style="width:18px;" src="'. base_url().'assets/img/popup-close.png"></a></div>
		  						<div id="signupfree" class=" popup_signupfree">
										<form style="padding-left: 38px; padding-top: 10px;" name="schedule_form" method="post" action="'.site_url('myknewdog/schedule_edit').'">
                          	
                            <input type="hidden" name="form" value="section_3" />
							<input type="hidden" name="schedule_id" value="'.$schedule[0]['schedule_id'].'" />
                            <div class="sendingtoemail">
                                <label>Sending to email:</label>
                              
                                	<input type="hidden" name="sd_user_id" value="'.$user[0]['user_id'].'" />
                                    <select style="float:left;" name="sending_to_email">';
									$sending = ($schedule[0]['sending_to_email'] == $user[0]['primary_email']) ? "selected='selected'" : "";
                                    $data .='<option '.$sending.' value="'.$user[0]['primary_email'].'">'.$user[0]['primary_email'].'</option>
                                	</select>
                               
                            	<a>Go premium to add more e-mail addresses!</a>
                            </div>
                            <section id="sendingtoemail_type">
                            <div class="sending row">
                                <div class="heading">Sending</div>
								<span style="display:none;" id="schedule_sending">'.$schedule[0]['sending'].'</span>
                                <p>
                                    <label>';
									$sending_1 = ($schedule[0]['sending'] == "Daily") ? "checked='checked'" : "";
                                   $data .='<input '.$sending_1.' onclick="schedule_set(this.id,\'popup\')" type="radio" id="Daily"  value="Daily" name="sending">Daily</label>
                                    <br>
                                    <label>';
									$sending_2 = ($schedule[0]['sending'] == "Weekly") ? "checked='checked'" : "";
                                   $data .='<input '.$sending_2.' onclick="schedule_set(this.id,\'popup\')" type="radio" id="Weekly"  value="Weekly" name="sending">Weekly</label>
                                    <br>
                                    <label>';
									$sending_3 = ($schedule[0]['sending'] == "Monthly") ? "checked='checked'" : "";
									$data .='<input '.$sending_3.' onclick="schedule_set(this.id,\'popup\')" type="radio" id="Monthly" value="Monthly" name="sending">Monthly</label>
                                    <br>
                                    <label>';
									$sending_4 = ($schedule[0]['sending'] == "Yearly") ? "checked='checked'" : "";
                                    $data .='<input '.$sending_4.' onclick="schedule_set(this.id,\'popup\')" type="radio" id="Yearly"  value="Yearly" name="sending">Yearly</label>
                                    <br>
                                </p>
                               
                            </div>
                            <div class="everyweekson row">
                                <div class="heading"><label>every:</label><input value="'.$schedule[0]['every'].'" type="text" placeholder="1" name="every">week(s) on</div>
                                    <div style="float:left;">';
									$weeks_on = explode(",", $schedule[0]['weeks_on']);
									//print_r($weeks_on);
									$weeks_on_1 = (in_array("Monday",$weeks_on)) ? "checked='checked'" : "";
                                   $data .='<div><input '.$weeks_on_1.' type="checkbox" value="Monday" name="weeks_on[]"><label>Monday</label></div>';
								   $weeks_on_2 = (in_array("Tuesday",$weeks_on)) ? "checked='checked'" : "";
                                   $data .='<div><input '.$weeks_on_2.' type="checkbox" value="Tuesday" name="weeks_on[]"><label>Tuesday</label></div>';
								   $weeks_on_3 = (in_array("Wednesday",$weeks_on)) ? "checked='checked'" : "";
                                   $data .='<div><input '.$weeks_on_3.' type="checkbox" value="Wednesday" name="weeks_on[]"><label>Wednesday</label></div>';
								   $weeks_on_4 = (in_array("Thursday",$weeks_on)) ? "checked='checked'" : "";
                                   $data .= '<div><input '.$weeks_on_4.' type="checkbox" value="Thursday" name="weeks_on[]"><label>Thursday</label></div>
                                    </div>
                                    <div style="float:right;">';
									$weeks_on_5 = (in_array("Friday",$weeks_on)) ? "checked='checked'" : "";
                                    $data .='<div><input '.$weeks_on_5.' type="checkbox" value="Friday" name="weeks_on[]"><label>Friday</label></div>';
									$weeks_on_6 = (in_array("Saturday",$weeks_on)) ? "checked='checked'" : "";
                                    $data .='<div><input '.$weeks_on_6.' type="checkbox" value="Saturday" name="weeks_on[]"><label>Saturday</label></div>';
									$weeks_on_7 = (in_array("Sunday",$weeks_on)) ? "checked='checked'" : "";
                                    $data .='<div><input '.$weeks_on_7.' type="checkbox" value="Sunday" name="weeks_on[]"><label>Sunday</label></div>
                                    </div>
                            </div>
                            <div class="time row">
                                <div class="heading"><label>At:</label>
                                
                                    <select name="at">';
                                  for($i = 0; $i < 24; $i++){
									 $at_1 = ($schedule[0]['at'] == $i) ? "selected='selected'" : "";
								$data .='<option '.$at_1.' value="'.$i.'">' . date("H.i", strtotime($i . ":00:00")) . '</option>'; 
								}
                                $data .='</select>
                               
                                </div>
                                <label>Ends:</label>
                                
                                <p style="margin-left:63px;">
                                    <label style="width:185px;">';
									$ends_1 = ($schedule[0]['ends'] == 'Never') ? "checked='checked'" : "";
                                    $data .='<input '.$ends_1.' type="radio" id="" value="Never" name="ends">
                                    <label>Never</label>
                                    </label>
                                    <br>
                                    <label style="width:185px;">
                                    <label for="ends_after1">';
									$ends_2 = ($schedule[0]['ends'] == 'after') ? "checked='checked'" : "";
                                    $data .='<input '.$ends_2.' type="radio" id="" value="after" name="ends" id="ends1">
                                    </label>
                                    <label>After</label>
                                    <label for="ends1"><input  type="text" placeholder="12" value="'.$schedule[0]['ends_after'].'" name="ends_after" id="ends_after1" class="occuranes"></label>
                                    <label>occurrences</label>
                                    </label>
                                    <br>
                                    <label style="width:185px;">';
									$ends_3 = ($schedule[0]['ends'] == 'on') ? "checked='checked'" : "";
                                    $data .='<label for="ends_on1"><input '.$ends_3.' type="radio" id="on1" value="on" name="ends"></label>
                                    <label>On:</label>
                                    <label for="on1"><input style="padding-left:3px;" id="ends_on1" type="text" value="'.$schedule[0]['ends_on'].'" placeholder="2014-05-16"  name="ends_on" class="occuranes_12172014"></label>
                                    </label>
                                    <br>
                                </p>
                                          
                                 </div>
                            </section>
                            <section id="summary">
                            	<div class="summary_title">Summary</div>
                                <div class="summary_emailid"><b>Weekly on Wednesday at 20:00 to username@dmail.com</b></div>
                                <div class="summary_cancel"><button style="background:none; border:none; float:right; cursor:pointer;" type="submit"><img src="'.base_url().'assets/img/summary_ok.png"></button><a class="popup_close" style="color:#E46C0A;" href="javascript:void(0)">cancel</a></div>
                                
                            </section>
                            </form>
								</div>
							</div>
						</div>
					</div>
				</div><script></script>';
		}else if($cls == 'profile'){
$data = '<div style="" class="popup_ajax profile">
		<div id="" class="freeusers_box signup_popup">
		<div class="popup_heading">Edit Profile</div>
		  <div class="popup_cancle"><a style="opacity:1;" class="popup_close" href="#"><img style="width:18px;" src="'. base_url().'assets/img/popup-close.png"></a></div>
		  <div id="signupfree" class=" popup_signupfree">
		  		<form style="margin-top:24px;" method="post" name="subscribe_1" id="subscribe_1" action="'.site_url('myknewdog/edit_profile').'">';
				if($number == 1){
					$data .= '<div class="profile_control">
						<label>Firstname:</label>
						<div class="controls">
							<input name="firstname" type="text" value="'.$user[0]['firstname'].'">
						</div>
					</div>
					<div class="profile_control">
						<label>Company:</label>
						<div class="controls">
							<input name="company_name" type="text" value="'.$user[0]['i_company_name'].'">
						</div>
					</div>
					<div class="profile_control">
						<label>Town:</label>
						<div class="controls">
							<input name="town" type="text" value="'.$user[0]['town'].'">
						</div>
					</div>
					<div class="profile_control">
						<label>Zip-code:</label>
						<div class="controls">
							<input name="zip_code" type="text" value="'.$user[0]['zip_code'].'">
						</div>
					</div>';
				$data .='<div class="profile_control">
						<label>Country:</label>
						<div class="controls">
						  <select name="country">';
						  for($l=0;$l<count($countries);$l++){
						 $data .='<option '.(($user[0]["country"] == $countries[$l]["id"]) ? "selected='selected'" : "").' value="'.$countries[$l]['id'].'">'.$countries[$l]["country_name"].'</option>';
						  }
						 $data .='</select>
						</div>
					</div>';
					}else if($number == 2){
						$data .= '<div class="profile_control">
						<label>Primary E-mail:</label>
						<div class="controls">
							<input name="primary_email" type="text" value="'.$user[0]['primary_email'].'">
						</div>
					</div>';
					}else if($number == 3){
						
				$data .='<div class="profile_control">
						<label>Languages:</label>
						<div class="controls">
						  <select style="min-height:72px;" multiple="multiple" name="language_id[]">';
						  $language_id = explode(",",$user[0]['language_id']);
						  for($l=0;$l<count($language);$l++){
						 $data .='<option '.((in_array($language[$l]['language_id'],$language_id)) ? "selected='selected'" : "").' value="'.$language[$l]['language_id'].'">'.$language[$l]['language_longform'].'</option>';
						  }
						 $data .='</select>
						</div>
					</div>';
					
			}else if($number == 4){
				$data .='<div class="profile_control">
						<label>Interest:</label>
						<div class="controls">
						   <select style="min-height:72px;"  multiple="multiple" name="user_interests[]">';
						  	$newsletter_keyword_ids = explode(",",$user[0]['user_interests']);
						   for($k=0;$k<count($keyword);$k++){
						 $data .='<option '.((in_array($keyword[$k]['newsletter_keyword_id'],$newsletter_keyword_ids)) ? "selected='selected'" : "").' value="'.$keyword[$k]['newsletter_keyword_id'].'">'.$keyword[$k]['en'].'</option>';
						  }
						 $data .='</select>
						</div>
					</div>';		
			}
			$data .='<div class="profile_action">
					<input style="margin-top:5px; margin-bottom:5px;" class="btn btn_main" value="Submit" name="Submit" type="submit" />
					</div>
				</form>
				</div>
		   </div>
	  </div>';
					
		}else if($cls == 'account_settings'){
$data = '<div style="" class="popup_ajax account_settings">
		<div id="" class="freeusers_box signup_popup">
		<div class="popup_heading">Edit Account settings</div>
		  <div class="popup_cancle"><a style="opacity:1;" class="popup_close" href="#"><img style="width:18px;" src="'. base_url().'assets/img/popup-close.png"></a></div>
		  <div id="signupfree" class=" popup_signupfree">
		  		<form style="margin-top:24px;" method="post" name="subscribe_1" id="subscribe_1" action="'.site_url('myknewdog/edit_account_settings').'">';
				if($number == 1){
					$data .= '<div class="profile_control">
						<label>Old Password:</label>
						<div class="controls">
							<input name="old_password" type="password" value="">
						</div>
					</div>
					<div class="profile_control">
						<label>Password:</label>
						<div class="controls">
							<input name="password" type="password" value="">
						</div>
					</div>
					<div class="profile_control">
						<label>Confirm password:</label>
						<div class="controls">
							<input name="password2" type="password" value="">
						</div>
					</div>';
				}else if($number == 2){
					$data .= '<div class="profile_control">
						<label>Language interface:</label>
						<div class="controls">
							<select name="language_interface">';
							 for($l=0;$l<count($site_language);$l++){
								$selected = ($user[0]['language_interface'] == $site_language[$l]['site_language_id']) ? 'selected="selected"' : '';
							 $data .='<option '.$selected.' value="'.$site_language[$l]['site_language_id'].'">'.$site_language[$l]['language_longform'].'</option>';
							  }
						$data .='</select>
						</div>
					</div>';
				}else if($number == 3){
					$data .= '<div class="profile_control">
						<label>Firstname:</label>
						<div class="controls">
							<input name="i_firstname" type="text" value="'.$user[0]['i_firstname'].'">
						</div>
					</div>
					<div class="profile_control">
						<label>Company:</label>
						<div class="controls">
							<input name="i_company_name" type="text" value="'.$user[0]['i_company_name'].'">
						</div>
					</div>
					<div class="profile_control">
						<label>Town:</label>
						<div class="controls">
							<input name="i_town" type="text" value="'.$user[0]['i_town'].'">
						</div>
					</div>
					<div class="profile_control">
						<label>Zip-code:</label>
						<div class="controls">
							<input name="i_zip_code" type="text" value="'.$user[0]['i_zip_code'].'">
						</div>
					</div>';
				$data .='<div class="profile_control">
						<label>Country:</label>
						<div class="controls">
						  <select name="i_country">';
						  for($l=0;$l<count($countries);$l++){
						 $data .='<option '.(($user[0]["i_country"] == $countries[$l]["id"]) ? "selected='selected'" : "").' value="'.$countries[$l]['id'].'">'.$countries[$l]["country_name"].'</option>';
						  }
						 $data .='</select>
						</div>
					</div>';
					}
					
			$data .='<div class="profile_action">
					<input style="margin-top:5px; margin-bottom:5px;" class="btn btn_main" value="Submit" name="Submit" type="submit" />
					</div>
				</form>
				</div>
		   </div>
	  </div>';
					
		}
echo $data;
?>