<div id="overlay"> 
  <!-- signup -->
  <div style="" class="popup signin">
    <div id="" class="freeusers_box signup_popup">
    <div class="popup_heading"><?php echo _clang(LOGIN_POPUP)?></div>
      <div class="popup_cancle"><a style="opacity:1;" class="popup_close" href="#"><img style="width:18px;" src="<?php echo base_url(); ?>assets/img/popup-close.png"></a></div>
      <div id="signupfree">
   <?php if(!empty($login_error)){?>
     <div style="margin:12px;" class="alert alert-error">
         <a class="close" data-dismiss="alert">&#215;</a>
           <?php echo $login_error;?>
         </div>
    <?php }?>
      <section class="" id="home_right">
      				
                    <article>
                        <div class="topheader">
                            <ul>
                                <li class="signinwith"><?php echo _clang(SIGN_IN_WITH_SIGNUP);?></li>
<?php
$facebook_login = K_facebook();
if(!empty($facebook_login)){
	$facebookurl = @$facebook_login['login_url'];
	}else{
		$facebookurl = '#';
		}
?>
                                <li class="facebook"><a href="<?php echo $facebookurl?>"><img src="<?php echo base_url(); ?>assets/img/facebook.png"><?php echo _clang(FACEBOOK)?></a></li>
  <?php
  										$google_login = K_google();
 										if(!empty($google_login['authUrl'])) //user is not logged in, show login button
										{
											$googleurl = @$google_login['authUrl'];
										}else{
											$googleurl = "#";
											}
										
?>
                                <li class="google"><a href="<?php echo $googleurl;?>"><img src="<?php echo base_url(); ?>assets/img/google.png"><?php echo _clang(GOOGLE)?></a></li>
                            </ul>
                        </div>
                        <p class="quicksignup_home"><?php echo _clang(QUICK_SIGN_IN_POPUP);?></p>
                        <form method="post" class="form_home" action="<?php echo site_url('signin/validate_credentials_front')?>">
                            <input class="username_home" name="username" type="text" placeholder="<?php echo _clang(USERNAME_LOGIN);?>">
                            <input class="username_home" name="password" type="password" placeholder="<?php echo _clang(PASSWORD_LOGIN);?>"><br/>
                            <input style="margin-top:5px; margin-bottom:5px;" class="btn btn_main" value="Sign In Now!" name="Submit" type="submit" />
                        </form>
                    </article>
                </section>
     		</div>
       </div>
  </div>
<!-- signup end-->
<!-- advace_search_popup -->
<div class="popup advance_search_popup">
	<div class="freeusers_box advancedsearch_popup_box">
        <div class="gopremium_cancell_btn"><a class="popup_close" href="javascript:void(0);"><img src="<?php echo base_url(); ?>assets/img/gopremiumcancell.png"></a></div>
        <div class="heading">Find exactly what you’re looking for with the<br>Advanced search feature for Premium Members</div>
        <p>Get the Advanced search now to enhance your search<br>sending.</p>
        <div class="gopremium_btn"><a href="#"><img src="<?php echo base_url(); ?>assets/img/gopremium.png"></a><span><a class="popup_close" href="javascript:void(0);">no thank you</a></span></div>
     </div>
  </div>  
<!-- advace_search_popup end -->
<!-- advace_search_popup -->
<div class="popup manage_schedule_popup_1">
<div class="freeusers_box manage_schedulingof_newsletter_popup">
    <div class="gopremium_cancell_btn"><a class="popup_close" href="javascript:void(0);"><img src="<?php echo base_url(); ?>assets/img/gopremiumcancell.png"></a></div>
    <div class="heading">Get your newsletter exactly when you need it with<br>the Advanced Scheduling feature for premium<br>Members</div>
    <p>Get the Advanced scheduling now to enhance your newsletter<br>sending.</p>
    <div class="gopremium_btn"><a href="#"><img src="<?php echo base_url(); ?>assets/img/gopremium.png"></a></div>
</div>
</div>
<!-- advace_search_popup end -->
<!-- advace_search_popup 2 -->
<div class="popup manage_schedule_popup_2">
<div class="freeusers_box subscribetonewsletter_popup">
    <div class="gopremium_cancell_btn"><a class="popup_close" href="javascript:void(0);"><img src="<?php echo base_url(); ?>assets/img/gopremiumcancell.png"></a></div>
    <div class="heading">Get your newsletter exactly when you need it with<br>the Advanced Scheduling feature for premium<br>Members</div>
    <p>Get the Advanced scheduling now to enhance your newsletter<br>sending.</p>
    <div class="gopremium_btn"><a href="#"><img src="<?php echo base_url(); ?>assets/img/gopremium.png"></a></div>
    <div class="gopremium_btn"><a onclick="subcribe_1_submit('subscribe_1');" class="popup_close" href="javascript:void(0);">continue without scheduling</a></div>
    <div class="gopremium_btn"><label style="color:#808080;">(you will get it at its arrival to our database)</label></div>
</div>
</div>
<!-- advace_search_popup end 2 -->
<!-- advace_search_popup 3 -->
<div class="popup manage_schedule_popup_3">
<div class="freeusers_box">
<div class="gopremium_cancell_btn"><a class="popup_close" href="javascript:void(0);"><img src="<?php echo base_url(); ?>assets/img/gopremiumcancell.png"></a></div>
<div class="heading">Get your newsletter exactly when you need it with<br>the Advanced Scheduling feature for premium<br>Members</div>
<p>Get the Advanced scheduling now to enhance your newsletter<br>sending.</p>
<div class="gopremium_btn"><a href="#"><img src="<?php echo base_url(); ?>assets/img/gopremium.png"></a></div>
<span>(Without schedulimg you will get your newsletter at its arrival to<br>our database)</span>
</div>
</div>
<!-- advace_search_popup end 3 -->

</div>


