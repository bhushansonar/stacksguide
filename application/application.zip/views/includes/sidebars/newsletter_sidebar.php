<?php 
$this->load->model('newsletter_model');
$newsletter_sidebar = $this->newsletter_model->get_newsletter_front('', 'newsletter_id', 'DESC', '3','0','Active');    
?>
<aside id="sidebar">
                <div id="sidebar_right">
                    <aside id="widget"><h3 class="widget-title">New in our database:</h3>			
                        <div class="widget_content">
                            <div class="thismightalsointerestyou">
                            <?php for($i=0;$i<count($newsletter_sidebar);$i++){?>
                                <div class="antohernewsletter">
                                    <div class="antohernewsletter_img"><a href="<?php echo site_url('newsletter/specific')."/".url_title($newsletter_sidebar[$i]['newsletter_name'],'dash',true)."/".$newsletter_sidebar[$i]['newsletter_id']?>">
                                     <?php if(!empty($newsletter[$i]['screenshot'])){?>
                                    <img style="width:40px; height:40px;" src="<?php echo base_url(); ?>uploads/<?php echo $newsletter[$i]['screenshot'];?>">
                                    <?php }else{?>
                                    <img style="width:40px; height:40px;" src="<?php echo base_url(); ?>assets/img/authornewsletter.png">
                                    <?php }?>
                                    </a></div>
                                    <div class="antohernewsletter_name"><a href="<?php echo site_url('newsletter/specific')."/".url_title($newsletter_sidebar[$i]['newsletter_name'],'dash',true)."/".$newsletter_sidebar[$i]['newsletter_id']?>"><?php echo $newsletter_sidebar[$i]['newsletter_name']?></a></div><div class="antohernewsletter_name"><span><label>Author:</label><?php echo $newsletter_sidebar[$i]['author_name']?></span></div>
                                </div>
                                <?php }?>
                                <?php /*?><div class="antohernewsletter">
                                    <div class="antohernewsletter_img"><a target="_blank" href="#"><img src="<?php echo base_url(); ?>assets/img/automotive_europe.png"></a></div>
                                    <div class="antohernewsletter_name"><a target="_blank" href="#">Automotive News Europe</a><span><label>Author:</label>Max Carjunkie</span></div>
                                </div>
                                <div class="antohernewsletter">
                                    <div class="antohernewsletter_img"><a target="_blank" href="#"><img src="<?php echo base_url(); ?>assets/img/authornewsletter.png"></a></div>
                                    <div class="antohernewsletter_name"><a target="_blank" href="#">Another Newsletter</a><span><label>Author:</label>Another Author</span></div>
                                </div><?php */?>
                            </div>
                        </div>
                    </aside>
                    
                    <aside id="widget"><h3 class="widget-title">This might also interest you:</h3>			
                        <div class="widget_content">
                            <div class="thismightalsointerestyou">
                                <div class="antohernewsletter">
                                    <div class="antohernewsletter_img"><a target="_blank" href="#"><img src="<?php echo base_url(); ?>assets/img/authornewsletter.png"></a></div>
                                    <div class="antohernewsletter_name"><a target="_blank" href="#">Another Newsletter</a><span><label>Author:</label>Another Author</span></div>
                                </div>
                                <div class="antohernewsletter">
                                    <div class="antohernewsletter_img"><a target="_blank" href="#"><img src="<?php echo base_url(); ?>assets/img/authornewsletter.png"></a></div>
                                    <div class="antohernewsletter_name"><a target="_blank" href="#">Another Newsletter</a><span><label>Author:</label>Another Author</span></div>
                                </div>
                                <div class="antohernewsletter">
                                    <div class="antohernewsletter_img"><a target="_blank" href="#"><img src="<?php echo base_url(); ?>assets/img/authornewsletter.png"></a></div>
                                    <div class="antohernewsletter_name"><a target="_blank" href="#">Another Newsletter</a><span><label>Author:</label>Another Author</span></div>
                                </div>
                            </div>
                        </div>
                    </aside>
                    <aside id="widget" style="border-bottom:0;">		
                        <div class="widget_content">
                        <div class="wanted"><img src="<?php echo base_url(); ?>assets/img/wanted.png"></div>
                        </div>
                    </aside>                    
                 </div>
           </aside>