<main>
 <?php //echo '<pre>';print_r($this->session->userdata);
 //echo '<pre>';print_r($_COOKIE);
 //echo $_SESSION['token'];
 //echo '<pre>';	print_r($guser);
$facebook_login = K_facebook();
if(!empty($facebook_login)){
	$facebookurl = @$facebook_login['login_url'];
	}else{
		$facebookurl = '#';
		}
$google_login = K_google();
 										if(!empty($google_login['authUrl'])) //user is not logged in, show login button
										{
											$googleurl = @$google_login['authUrl'];
										}else{
											$googleurl = "#";
											}

 ?>
<div class="set_errors">
<?php

echo validation_errors();
      if($this->session->flashdata('flash_message')){
		  
          echo '<div class="alert '.$this->session->flashdata("flash_class").'">';
            echo '<a class="close" data-dismiss="alert">&#215;</a>';
            echo $this->session->flashdata("flash_message");
          echo '</div>';       
      }?>
</div>
        <section class="homepage" id="container">
        <div class="homepage_inner">
        	
            <article style="margin:30px auto 19px 0;">
            <?php echo cms_block('HOME_TOP'); ?>
                <?php /*?><h1 style="margin:0 0 0.8125em; font-weight:bold; font-size:190%;"><?php echo _clang(HOME_HEAD_TEXT);?></h1>
                <p><strong>
                        <span style=" font-size:large;"><?php echo _clang(HOME_SUB_TEXT);?></span>
                   </strong>
                </p><?php */?>
            </article>
            
            <section id="home_left">
            	<?php echo cms_block('HOME_IMAGE');?>
          	<?php /*?><img src="<?php echo base_url(); ?>assets/img/formimg_home.PNG"><?php */?>
            </section>
            
            <section id="home_right">
            <?php if(!$this->session->userdata('is_logged_in')){?>
            <div class="topheader">
                <ul>
                    <li class="signinwith"><?php echo _clang(SIGN_IN_WITH);?></li>
                    <li class="facebook"><a href="<?php ?>"><img src="<?php echo base_url(); ?>assets/img/facebook.png"><?php echo _clang(FACEBOOK);?></a></li>
                    <li class="google"><a href="<?php ?>"><img src="<?php echo base_url(); ?>assets/img/google.png"><?php echo _clang(GOOGLE);?></a></li>
                </ul>
            </div>
            <br/>
            <p class="quicksignup_home"><?php echo _clang(QUICK_SING_UP);?></p>
            <form class="form_home">
                <input class="username_home" name="" type="text" placeholder="Username">
                <input class="emailaddress_home" name="" type="text" placeholder="Your e-mail address">
                <input class="signup_btn" name="" type="button">
            </form>
            <p class="freeaccount quicksignup_home"><?php echo _clang(FOR_A_FREE_ACCOUNT);?></p>
            <?php }?>
            <?php /*?><span class="freeaccount_text">
            	<?php echo _clang(AND_FROM_NOW);?>
            <br/>
            <span class="learnmore_home"><?php echo _clang(LEARN_MORE_H);?>...</span>
            </span><?php */?>
            <?php echo cms_block('HOME_SIGN_UP_BOTTOM');?>
            </section>
		</div>
        </section>
        </main>