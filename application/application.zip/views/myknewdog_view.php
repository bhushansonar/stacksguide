<main>
<link href="<?php echo site_url('assets/css')?>/rateit.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="//code.jquery.com/ui/1.10.4/themes/smoothness/jquery-ui.css">
<script src="//code.jquery.com/ui/1.10.4/jquery-ui.js"></script>
<script type="text/javascript">
 $(function() {
	$( "#ends_on" ).datepicker();
	 $( "#ends_on" ).datepicker(  "option", "dateFormat", 'yy-mm-dd' );
});
</script>
<?php 
$this->load->model('newsletter_model');
$this->load->model('user_model');
$this->load->model('newsletter_language_model');
$this->load->model('newsletter_keyword_model');
$this->load->model('schedule_model');
$ci =& get_instance(); 
$ci->load->model('subscribe_model'); 
$user_id = $this->session->userdata("user_id"); 
//echo '<pre>'; print_r($user);
//echo '</pre>';
?>
<div class="set_errors">
<?php
	if($this->session->flashdata('validation_error_messages')){
		echo $this->session->flashdata('validation_error_messages');
		}
 echo validation_errors();
     if($this->session->flashdata('flash_message')){
		 //echo "->".$this->session->flashdata("flash_mynl_tab"); 
          echo '<div class="alert '.$this->session->flashdata("flash_class").'">';
            echo '<a class="close" data-dismiss="alert">&#215;</a>';
            echo $this->session->flashdata("flash_message");
          echo '</div>';       
      }
	  //echo '<pre>'; print_r($user); die;
	  ?>
</div>
      <section class="knewdog findnewsletter" id="container">
            <section id="knewdog_leftbar">
            	<div class="knewdog_leftbar_inner">
                    <div id="tabsholder">
                        <ul class="tabs">
                            <li style="line-height:33px;" onclick="display_tabs(this.id)" id="tab_1" style="">My Profile</li>
                            <li onclick="display_tabs(this.id)" id="tab_2" >My<br/>Newsletters</li>
                            <li onclick="display_tabs(this.id)" id="tab_3">My<br>Schedules</li>
                            <li onclick="display_tabs(this.id)" id="tab_4">Account<br>Settings</li>
                        </ul>
                        
                    </div>
        <!--------------------------------------------Section 1 --------------------------------------------------->
                    <section class="section" style="display:none;" id="section_1">
                       <?php if($user[0]['account_confirmed'] == 'NO'){?>
                        <div class="notes">System messagetext: "Please confirm your account to get access to all features!"</div>
                        <?php }?>
                        <div class="profilepicture">
                        <?php 
						
						if(@getimagesize((site_url('uploads/avatar')."/".$user[0]['avatar']))){?>
                  <img style="width:161px; height:213px;" src="<?php echo site_url('uploads/avatar')."/".$user[0]['avatar'];?>" >
						<?php }else{?>
                        <img src="<?php echo base_url(); ?>assets/img/avatarpic.png">
                        <?php }?>
                        </div>
                        <div class="profile_detail">
                            <div class="username"><?php echo $user[0]['username'];?></div>
                           <?php 
							
							switch ($user[0]['type_of_membership']) {
									case 'normal_admin':
										$type_of_membership = "Normal Admin";
										break;
									case 'power_admin':
										$type_of_membership = "Power Admin";
										break;
									case 'FREE':
										$type_of_membership = "Free";
										break;
									case 'PRE1':
										$type_of_membership = "Premium type 1";
										break;
									case 'PRE2':
										$type_of_membership = "Premium type 2";
										break;
									case 'PUB1':
										$type_of_membership = "Publisher type 1";
										break;
									case 'PUB2':
										$type_of_membership = "Publisher type 2";
										break;
									case 'CAAD':
										$type_of_membership = "Company account Administrator";
										break;
									case 'CAUS':
										$type_of_membership = "Company Account";
										break;			
								}
							?>
                            <span>You are logged in as <?php echo $type_of_membership;?> User <a href="#">(go Premium!)</a></span>
                            <form id="profilepicture_detail" class="autosubmit" method="POST" action="./ajax-update.php">
                                <div class="firstname">
                                	<label>Firstname:&nbsp;</label> <div><label><?php echo (!empty($user[0]['firstname']) ? $user[0]['firstname'] : "N/A");?></label></div>
                                	<span class="editbtn"><span style="cursor:pointer;" onclick="popups_ajax('profile','1')" ><img src="<?php echo base_url(); ?>assets/img/edit.png"></span></span>
                                </div>
                                <div><label>Company:&nbsp;</label><div><label><?php echo (!empty($user[0]['i_company_name'])) ? $user[0]['i_company_name'] : "N/A"?></label></div></div>
                                <div><label>Town:&nbsp;</label><div><label><?php echo (!empty($user[0]['town'])) ? $user[0]['town'] : "N/A";?></label></div></div>
                               
                                <div><label>Zip-code:&nbsp;</label><div><label><?php echo (!empty($user[0]['zip_code'])) ? $user[0]['zip_code'] : "N/A"; ?></label></div></div>
                               <?php 
								//country
								$country_id = !empty($user[0]['country']) ? $user[0]['country'] : "";
								if(!empty($country_id)){
								$country = $this->user_model->get_countries_by_id($country_id);
								$country = $country[0]['country_name'];
								}else{
									$country = "N/A";
									}
									
								?>
                                <div><label>Country:&nbsp;</label><div><label><?php echo $country;?></label></div></div>
                                
                                <div style="margin-top:15px;">
                                	<label>Your primary e-mail:</label><a href="mailto:<?php echo $user[0]['primary_email'];?>" style="margin-left:5px;"><?php echo $user[0]['primary_email'];?></a>
                                	<span class="editbtn"><span onclick="popups_ajax('profile','2')" style=" cursor:pointer;"><img src="<?php echo base_url(); ?>assets/img/edit.png"></span></span>
                                </div>
                                <div>
                                	<label>Additional email addresses:</label><a href="#" style="margin-left:5px;">Go Premium!</a>
                                    <span class="editbtn"><a href="#"><img src="<?php echo base_url(); ?>assets/img/edit.png"></a></span>
                                </div>
                                <div style="margin-top:15px;"><label style="margin-right:5px;">Your last login:</label><time><?php echo date('j, F Y',strtotime($user[0]['last_login']))?></time></div>
                            </form>
                        </div>
                            <article id="knewdog_article">
                            	<span style="margin-top:45px; font-size:13px; float:left;">
                                <b style="font-size:14px;">Tell us something about you</b> ! We will recommend you newsletters according to these infos.</span>
                                <div class="laungages"><label><b>Languages:</b></label>
                                <div class="laungages_con">
                                <?php if(!empty($user[0]['language_id'])){
									$newsletter_language_ids = explode(",",$user[0]['language_id']); 
									for($i=0;$i<count($newsletter_language_ids);$i++){
										$newsletter_language = $this->newsletter_language_model->get_language_by_id($newsletter_language_ids[$i]);
									?>
                                    <span id="del_<?php echo $newsletter_language_ids[$i]?>"><?php echo $newsletter_language[0]['language_longform']?><a onclick="profile_delete('language_id',<?php echo $newsletter_language_ids[$i]?>,'<?php echo $user_id?>')" style="cursor:pointer;"><img src="<?php echo base_url(); ?>assets/img/cancell.png"></a></span>
                                    <?php }?>
                                    <?php }?>
                                    <span onclick="popups_ajax('profile','3')" style=" cursor:pointer; font-weight:bold;">add one</span>
                                  </div>
                                </div>
                                <div class="interests"><label><b>Interests:</b></label>
                                	<div class="interests_con">
                                    <?php if(!empty($user[0]['user_interests'])){
									$newsletter_keyword_ids = explode(",",$user[0]['user_interests']); 
									for($i=0;$i<count($newsletter_keyword_ids);$i++){
										$newsletter_keyword = $this->newsletter_keyword_model->get_keyword_by_id($newsletter_keyword_ids[$i]);
									?>
                                    <span id="del_<?php echo $newsletter_keyword_ids[$i]?>"><?php echo $newsletter_keyword[0]['en']?><a onclick="profile_delete('user_interests',<?php echo $newsletter_keyword_ids[$i]?>,'<?php echo $user_id?>')" style="cursor:pointer;"><img src="<?php echo base_url(); ?>assets/img/cancell.png"></a></span>
                                    <?php }?>
                                    <?php }?>
                                    <span style="cursor:pointer;font-weight:bold;" onclick="popups_ajax('profile','4')" >add one</span>
                                    </div>
                                </div>
                            </article>
                    </section>
        <!--------------------------------------------Section 2 --------------------------------------------------->
                    <section class="section" style="display:none;" id="section_2">
                      <?php if(!empty($user_id)){?>
                    	<form method="post" action="<?php echo current_url();?>" name="mynewsletter_search" id="mynl_newsletter_search">
                        <input type="hidden" name="form" value="section_2" />
                            <div class="findnewsletter_form">
                             
                                <article>
                               
                                    <div class="title">Advanced Search</div>
                                    <div class="fullwidth_input"><input value="<?php echo $mynl_search_string_selected?>" name="mynl_search_string" type="text"placeholder="for ex.: keyword, title, author, text..."></div>
                                   <div class="<?php echo get_if_free_user('class_free_user')?>"> 
                                    <div class="selectgroup">
                                    <div class="<?php echo get_if_free_user('class_free_user_overlay_1')?>" <?php echo get_if_free_user('advance_search_popup')?>></div>
                                        <div class="select"><label>Language:</label>
                                        <select name="mynl_language_id">
                                        	<option value="">(all)</option>
                                           <?php for($l=0;$l<count($language);$l++){?>
                                            <option <?php echo ($mynl_selected_language_id == $language[$l]['language_id']) ? 'selected="selected"' : ""?>  value="<?php echo $language[$l]['language_id']; ?>"><?php echo $language[$l]['language_longform'];?></option>
                                          <?php }?>
                                        </select>
                                        </div>
                                        <div class="select"><label>Category:</label>
                                        <?php //echo $selected_newsletter_category;?>
                                        <select name="mynl_newsletter_category">
                                            <option  value="">(ALL)</option>
                                           <?php for($c=0;$c<count($category);$c++){?>
                                            <option  <?php echo ($mynl_selected_newsletter_category == $category[$c]['en']) ? 'selected="selected"' : ''?> value="<?php echo $category[$c]['en']; ?>"><?php echo $category[$c]['en'];?></option>
                                          <?php }?>
                                          </select>
                                        </div>
                                        <div class="select"><label>Rating:</label><select name="mynl_rating_id"><option value="">(all)</option></select></div>
                                    </div>
                                    <div class="selectgroup">
                                    <div class="<?php echo get_if_free_user('class_free_user_overlay_2')?>" <?php echo get_if_free_user('advance_search_popup')?>></div>
                                        <div class="select"><label>Location:</label>
                                        	<select name="mynl_author_country">
                                            		<option value="">(country)</option>
												 <?php for($l=0;$l<count($countries);$l++){?>
                                                  <option <?php echo $mynl_selected_author_country == $countries[$l]['id'] ? 'selected="selected"' : ''?>  value="<?php echo $countries[$l]['id']?>"><?php echo $countries[$l]['country_name']?></option>
                                                  <?php }?>
                                         </select>
                                        </div>
                                        <div class="select"><label></label><input style="padding:2.5%" placeholder="Zip code" type="text" value="<?php echo $mynl_selected_author_zipcode;?>" name="mynl_author_zipcode" /></div>
                                        <div class="select cancel_button"><label></label>
                                            <div style="float:right;" class="summary_cancel">
                                            	<a class="cancle" href="<?php echo site_url('myknewdog')?>">cancle</a>
                                                <!--<input class="cancle" type="reset" value="cancle" />-->
                                                <button class="btnsearch" name="" type="submit"><img src="<?php echo base_url(); ?>assets/img/search.png"></button>
                                            </div>
                                        </div>
                                    </div>
                                   </div>

                                </article>
                            </div>
                            <article>
                               <div class="pager">
                               <?php if($mynl_page == 0){ $mynl_page = 1;}else{ $mynl_page = $mynl_page;}
							//$total = count($newsletter);
							//echo $result_show_count1 = ($limit_end  + $limit_start);
							//echo ($page * $limit_start)."=".$total_rows;
								if($mynl_total_rows <= ($mynl_page * $mynl_limit_start)){
									$mynl_result_show_count = $mynl_total_rows;
									}else{
										$mynl_result_show_count = $mynl_page * $mynl_limit_start;
								}
								   /*if($total > $total_rows){ $result_total = $total;}else{ $result_total = $total_rows;}*/
							   ?>
                                   <div class="result"><?php echo "Result ".($mynl_limit_end + 1)."-".($mynl_result_show_count)." out of ".$mynl_total_rows?><!--Result 1-10 out of 986--></div>
                                   <div class="sortby">
                                       <label>Sort by:</label>
                                       <?php //echo $order;?>
                                       <select name="mynl_order">
                                       <option <?php echo $mynl_order == 'newsletter_name' ? 'selected="selected"' :""  ?> value="newsletter_name">newsletter title</option>
                                       <option <?php echo $mynl_order == 'author_name' ? 'selected="selected"' :""  ?> value="author_name">newsletter author</option>
                                       <option <?php echo $mynl_order == 'newsletter_id' ? 'selected="selected"' :""  ?> value="newsletter_id">newest first</option>
                                       </select>
                                   </div>
                                   <!--<div class="view"><label>View:</label><a href="#"><img src="<?php echo base_url(); ?>assets/img/view.png"></a></div>-->
                               </div>
                            </article>
                             </form>
                            <article style="clear:both;" class="reviewlist">
                            <?php for($i=0;$i<count($mynl_newsletter);$i++){?>
                                <div class="dashreview">
                                    <div class="review_img"><a href="<?php echo site_url('newsletter/specific')."/".url_title($mynl_newsletter[$i]['newsletter_name'],'dash',true)."/".$mynl_newsletter[$i]['newsletter_id']?>">
                                    <?php if(!empty($mynl_newsletter[$i]['screenshot'])){?>
                                    <img style="width:79px;" src="<?php echo base_url(); ?>uploads/<?php echo $mynl_newsletter[$i]['screenshot'];?>"></a></div>
                                    <?php }else{?>
                                    <img style="width:79px;" src="<?php echo base_url(); ?>assets/img/authornewsletter.png"></a></div>
                                    <?php }?>
                                    <div class="review_detail">
                                    <a class="name" href="<?php echo site_url('newsletter/specific')."/".create_slug($mynl_newsletter[$i]['newsletter_name'],100)."/".$mynl_newsletter[$i]['newsletter_id']?>"><?php echo $mynl_newsletter[$i]['newsletter_name']?></a><br/>
                                    <label style="color:#808080;">Author: </label><?php echo $mynl_newsletter[$i]['author_name']?>
                                    <?php
									$get_rate = $this->newsletter_model->get_rate_by_user($mynl_newsletter[$i]['newsletter_id']);
									
										include("rating/rating_calculation.php");
								
									
									$user_id = $this->session->userdata("user_id"); 
									//echo "user_id->".$newsletter[$i]["user_id"];
									$wherefield =array();
									$wherevalue =array();
									
									$wherefield =array("join_newsletter_id");
									$wherevalue = array($mynl_newsletter[$i]["newsletter_id"]);
									$get_news_user_id = $this->newsletter_model->get_rate_by_field($wherefield,$wherevalue);
								/*if(!empty($user_id)){
									if(count($get_news_user_id) > 0){
											$readonly = "true";		
								    }else{
										$readonly = "false";	
										}
								}else{
										$readonly = "true";
									}*/
									$readonly = "true";
									
									//$data['get_rate'] = $get_rate;	
										?>
                                     <span class="rating_hover">
                                    <div style="margin-left: 20px; display: inline-block; vertical-align: text-bottom;" data-productid="<?php echo $mynl_newsletter[$i]['newsletter_id']; ?>" title="<?php echo $avg_round;?>" data-rateit-resetable="false" data-rateit-value="<?php echo $avg_round;?>" data-rateit-ispreset="true" data-rateit-reset="false" data-rateit-readonly="<?php echo $readonly?>" class="rateit" id="rateit9"></div>
									
									 <?php if(count($get_news_user_id) > 0){ ?>
                                    <img style="margin-left: 5px; vertical-align: text-top; display: inline-block;" src="<?php echo base_url(); ?>assets/img/review_down.png">
                                    <?php }?>
                                    <a style="text-decoration: none; margin-left: 3px; display: inline-block; vertical-align: top;" href="<?php echo site_url("newsletter/display-rate"."/".$mynl_newsletter[$i]['newsletter_id']);?>">(<?php echo (!empty($total_user_rate)) ? $total_user_rate : "0";?>)</a>
                                      <?php if(count($get_news_user_id) > 0){ ?>
                                    <div  class="rating_popup">
                                    	<?php $popupcss = "style='float:none; width:100%;'";?>
                                    	<?php include("rating/rating_view.php");?>
                                        <a href="<?php echo site_url("newsletter/display-rate"."/".$mynl_newsletter[$i]['newsletter_id']);?>">See all <?php echo (!empty($total_user_rate)) ? $total_user_rate : "0";?> customer reviews</a>
                                    </div>
                                    <?php }?>
                                    </span>
                               
                                    <br/>
                                    <?php echo $mynl_newsletter[$i]['description'];?>
                                    <?php
                                    $where_s_field_2 = array('s_newsletter_id');
									$where_s_value_2 = array($mynl_newsletter[$i]['newsletter_id']);
									$subscribed_2 = $this->subscribe_model->get_subscribe('', '', '', '', '',$where_s_field_2,$where_s_value_2);
									$count_subscribed = count($subscribed_2);
									?>
									<label style="color:#808080;"><?php echo $count_subscribed;?> subscribers, language: <?php echo (!empty($mynl_newsletter[$i]['newsletter_language']) ? $mynl_newsletter[$i]['newsletter_language'] : "N/A")?></label> 
                                    </div>
                                    
                                    <!--<div class="review_subscribe"><img src="<?php echo base_url(); ?>assets/img/evaluate.png" class="evaluate"><img src="<?php echo base_url(); ?>assets/img/unsubscribe.png"></div>-->
                                    
                                    <div class="review_subscribe">
                                   <?php if(!empty($user_id)){
									   
									   $where_Sfield = array();
									   $where_Svalue = array();
									   
									   $where_Sfield = array('s_newsletter_id','s_user_id');
									   $where_Svalue = array($mynl_newsletter[$i]['newsletter_id'],$user_id);
									  $subscribe = $ci->subscribe_model->get_subscribe('', '', '','', '',$where_Sfield,$where_Svalue);
				
									 		if(count($subscribe) > 0){
									   ?>
                                        <img style="cursor:pointer; float:none;" onclick="popups_ajax_unsubscribe('unsubscribe','<?php echo $mynl_newsletter[$i]['newsletter_id'] ?>','<?php echo $user_id?>')" src="<?php echo base_url(); ?>assets/img/unsubscribe.png">
                                        <a href="<?php echo site_url("newsletter/display-rate"."/".$mynl_newsletter[$i]['newsletter_id']);?>"><img src="<?php echo base_url(); ?>assets/img/evaluate.png" class="evaluate"></a>
                                        <!--<span style="float: right; margin-top: 20px; text-align: center; color:#808080; font-size: 11px;">
                                    You are already subscribed<br>Go to ”<u>My Newsletters</u>”<br>to manage<br>your subscriptions.</span>-->
                                       <?php }else{?>
                                    <img onclick="popups_ajax('subscribe_1','<?php echo $mynl_newsletter[$i]['newsletter_id'] ?>','<?php echo $user_id?>')" src="<?php echo base_url(); ?>assets/img/subscribe.png">
                                    <?php }
									 }?>
                                    </div>
                                    <!-- Schedule for newsletters-->
                                    <?php
									//$this->load->model('subscribe_model');
									$where_s_field = array('s_user_id','s_newsletter_id');
									$where_s_value = array($user_id,$mynl_newsletter[$i]['newsletter_id']);
									$subscribed_1 = $this->subscribe_model->get_subscribe('', '', '', '', '',$where_s_field,$where_s_value);
									//echo "schedule_id->".$subscribed_1[0]['schedule_id'];
									if($subscribed_1[0]['schedule_id'] != 0){
			
									$get_schedule_by_id = $this->schedule_model->get_schedule_by_id($subscribed_1[0]['schedule_id']);
									//echo '<pre>'; print_r($get_schedule_by_id);
									//echo '</pre>';
									$every = ($get_schedule_by_id[0]['every']) ? "every ".$get_schedule_by_id[0]['every'] ." Week": "";
									$week0 = ($get_schedule_by_id[0]['weeks_on']) ? "on ".$get_schedule_by_id[0]['weeks_on'] : "";
									 ?>
                                    <div class="sendingscheduale"><b>Sending Schedule:</b><label><?php echo $get_schedule_by_id[0]['sending']." ".$every." ".$week0." at ". date("H.i", strtotime($get_schedule_by_id[0]['at'] . ":00:00"))?></label></div><div class="sendingemail"><b>Sending to email:</b><label><?php echo $get_schedule_by_id[0]['sending_to_email']?></label><img style="cursor:pointer;" onclick="popups_ajax_schedule('schedule','<?php echo $get_schedule_by_id[0]['schedule_id']?>')" src="<?php echo base_url(); ?>assets/img/edit.png"></div>
                                    <?php }?>
                                    
                                    
                                    
                                </div>
                             <?php }?>   
                            </article>
                            <?php echo '<div class="pagination">'.$mynl_link.'</div>'; ?>
                            <?php }else{?>
                     	<div class="findnewsletter_form">
                     		<h1 style="clear: both; color: black; text-align: center; margin-top: 64px;">Please <a style="cursor:pointer;" onclick="popup('signin')">Login</a> to view My newsletter!</h1>  
                       </div>
                     <?php }?>
                       		
                   </section>
         <!--------------------------------------------Section 3 --------------------------------------------------->           
                   <section class="section" style="display:none;" id="section_3">
                    	<div class="myscheduale_form site">
                        <div class="<?php echo get_if_free_user('class_free_user')?>">
                        	<div class="<?php echo get_if_free_user('class_free_user_overlay_5')?>" <?php echo get_if_free_user('manage_schedule_popup_3')?>></div>
                          <form name="schedule_form" method="post" action="<?php echo site_url('myknewdog/schedule')?>">
                          	<!--<input type="hidden" value="schedule" name="schedule" />-->
                            <input type="hidden" name="form" value="section_3" />
                            <div class="setnewscheduale_title">Set new schedule:</div>
                            <div class="sendingtoemail">
                                <label>Sending to email:</label>
                              
                                	<input type="hidden" name="sd_user_id" value="<?php echo $user_id?>" />
                                    <select style="float:left;" name="sending_to_email">
                                    	<option value="<?php echo $user[0]['primary_email']?>"><?php echo $user[0]['primary_email']?></option>
                                	</select>
                               
                            	<a>Go premium to add more e-mail addresses!</a>
                            </div>
                            <section id="sendingtoemail_type">
                            <div class="sending row site">
                                <div class="heading">Sending</div>
                                <p>
                                    <label>
                                    <input onclick="schedule_set(this.id,'site')" type="radio" id="Daily"  value="Daily" name="sending">Daily</label>
                                    <br>
                                    <label>
                                    <input onclick="schedule_set(this.id,'site')" type="radio" id="Weekly"  value="Weekly" name="sending">Weekly</label>
                                    <br>
                                    <label>
                                    <input onclick="schedule_set(this.id,'site')" type="radio" id="Monthly" value="Monthly" name="sending">Monthly</label>
                                    <br>
                                    <label>
                                    <input onclick="schedule_set(this.id,'site')" type="radio" id="Yearly"  value="Yearly" name="sending">Yearly</label>
                                    <br>
                                </p>
                               
                            </div>
                            <div class="everyweekson row">
                                <div class="heading"><label>every:</label><input type="text" placeholder="1" name="every">week(s) on</div>
                                    <div style="float:left;">
                                    <div><input type="checkbox" value="Monday" name="weeks_on[]"><label>Monday</label></div>
                                    <div><input type="checkbox" value="Tuesday" name="weeks_on[]"><label>Tuesday</label></div>
                                    <div><input type="checkbox" value="Wednesday" name="weeks_on[]"><label>Wednesday</label></div>
                                    <div><input type="checkbox" value="Thursday" name="weeks_on[]"><label>Thursday</label></div>
                                    </div>
                                    <div style="float:right;">
                                    <div><input type="checkbox" value="Friday" name="weeks_on[]"><label>Friday</label></div>
                                    <div><input type="checkbox" value="Saturday" name="weeks_on[]"><label>Saturday</label></div>
                                    <div><input type="checkbox" value="Sunday" name="weeks_on[]"><label>Sunday</label></div>
                                    </div>
                            </div>
                            <div class="time row">
                                <div class="heading"><label>At:</label>
                                
                                    <select name="at">
                                    <!--<option>12:00</option>
                                    <option>11:00</option>
                                    <option>10:00</option>-->
                                  <?php  for($i = 0; $i < 24; $i++){
									   echo '<option value="'.$i.'">' . date("H.i", strtotime($i . ":00:00")) . '</option>'; }?>
                                	</select>
                               
                                </div>
                                <label>Ends:</label>
                                
                                <p style="margin-left:63px;">
                                    <label style="width:185px;">
                                    <input type="radio" id="" value="Never" name="ends">
                                    <label>Never</label>
                                    </label>
                                    <br>
                                    <label style="width:185px;">
                                    <label for="ends_after">
                                    	<input type="radio" id="" value="after" name="ends" id="ends">
                                    </label>
                                    <label>After</label>
                                    <label for="ends"><input type="text" placeholder="12" name="ends_after" id="ends_after" class="occuranes"></label>
                                    <label>occurrences</label>
                                    </label>
                                    <br>
                                    <label style="width:185px;">
                                    <label for="ends_on"><input type="radio" id="on" value="on" name="ends"></label>
                                    <label>On:</label>
                                    <label for="on"><input style="padding-left:3px;" id="ends_on" type="text" value="" placeholder="2014-05-16"  name="ends_on" class="occuranes_12172014"></label>
                                    </label>
                                    <br>
                                </p>
                                          
                                 </div>
                            </section>
                            <section id="summary">
                            	<div class="summary_title">Summary</div>
                                <div class="summary_emailid"><b>Weekly on Wednesday at 20:00 to username@dmail.com</b></div>
                                <div class="summary_cancel"><button style="background:none; border:none; float:right; cursor:pointer;" type="submit"><img src="<?php echo base_url(); ?>assets/img/summary_ok.png"></button><a onclick="submitform('gotoschedule')" href="javascript:void(0)">cancel</a></div>
                                
                            </section>
                            </form>
                            
                            <form id="gotoschedule" action="<?php echo site_url('myknewdog');?>" method="post">
                            <input type="hidden" name="form" value="section_3" /> 
                            </form>
                         </div>
                         </div>
                        <section id="yourscheduales">
                	<div class="yourscheduales_title">Your Schedules:</div>
                 	<div class="yourscheduales_list">
                    <?php for($i=0;$i<count($schedule);$i++){?>
                        <div>
                            <label><span><?php echo ($i+1);?>)</span><div style="display: inline-block; width: 548px;"> <?php echo $schedule[$i]['sending']?> <?php echo ($schedule[$i]['every']) ? "every ".$schedule[$i]['every'] ." Week": ""?> <?php echo ($schedule[$i]['weeks_on']) ? "on ".$schedule[$i]['weeks_on'] : ""?> at <?php echo date("H.i", strtotime($schedule[$i]['at'] . ":00:00"))?> to email <?php echo $schedule[$i]['sending_to_email']?></div></label>
                            <span class="editbtn"><a onclick="popups_ajax_schedule('schedule','<?php echo $schedule[$i]['schedule_id']?>')" href="javascript:void(0)"><img src="<?php echo base_url(); ?>assets/img/edit.png"></a></span>
                         <?php /*?> <form id="gotoschedule_<?php echo $i?>" action="<?php echo site_url('myknewdog');?>" method="post">
                            <input type="hidden" name="form" value="section_3" /> 
                            <input type="hidden" name="schedule_id" value="<?php echo $schedule[$i]['schedule_id']?>" />
                          </form><?php */?>
                        </div>
                     <?php }?>
                       <!-- <div class="addmorecheduales"><a href="#">Add more Schedules!</a></div>-->
                	 </div>
                </section>
                    </section>
          <!--------------------------------------------Section 4 --------------------------------------------------->           
                    <section class="section" style="display:none;" id="section_4">
                    	<div class="accountsetting">
                            
                            <div style="margin-top:15px;" class="login_profile">
                            <div class="accountsetting_title">Login data and interface language</div>
                            <div><label>Username:</label><?php echo $user[0]['username']?><span style="color:#808080;"> (can not be changed)</span></div>
                            <div><label>Password:</label>********<span style="float:right;"><a onclick="popups_ajax('account_settings','1')" href="javascript:void(0);"><img src="<?php echo base_url(); ?>assets/img/edit.png"></a></span></div>
                            <div><label style="height:45px;">System Laungage:</label>In which language would you like to use knewdog?<span style="float:right;"><a onclick="popups_ajax('account_settings','2')" href="javascript:void(0);"><img src="<?php echo base_url(); ?>assets/img/edit.png"></a></span>
                            <br><label><?php echo $user[0]['language_longform'];?></label></div>
                            </div>
                            
                            <div class="login_profile">
                            <div class="accountsetting_title">Privacy, Notifications and Content</div>
                            <div>
                                <label style="min-height:70px;">Show my:</label><a href="#"><img src="<?php echo base_url(); ?>assets/img/true.png"></a>Username Only<br>
                                <a href="#"><img src="<?php echo base_url(); ?>assets/img/wrong.png"></a>my real name,address and profile photo<br>
                                <a href="#"><img src="<?php echo base_url(); ?>assets/img/true.png"></a>I'd like to receive HTML e-mails.
                            </div>
                                <div>
                                <label>Advertisement:</label>
                                	<?php if($user[0]['no_ads'] == "YES"){?>
                                    <a href="#">
                                    <img src="<?php echo base_url(); ?>assets/img/wrong.png"></a>Don't send me ads,Please!<span style="color:#808080; "> (For Premium only! <a href="#">Go Premium!</a>)</span>
                                    <?php }else{?>
                                    <a href="#">
                                    <img src="<?php echo base_url(); ?>assets/img/true.png"></a>Don't send me ads,Please!<span style="color:#808080; ">
                                    <?php }?>
                                 </div>
                                <div><label>Content:</label>
                               <?php if($user[0]['no_ads'] == "YES"){?> 
                                <a href="#"><img src="<?php echo base_url(); ?>assets/img/wrong.png"></a>I'd like to see "adult content.<span style="color:#808080;"> (For Premium only!
                                <a href="#">Go Premium!</a>)</span>
                                <?php }else{?>
                                <a href="#"><img src="<?php echo base_url(); ?>assets/img/true.png"></a>I'd like to see "adult content.<span style="color:#808080;">
                                <?php }?>
                                </div>
                            </div>
                            
                            <div class="login_profile">
                            <div class="accountsetting_title">Invoices</div>
                            <div>
                                <label style="min-height:129px;">Invoice address:</label>
                                Firstname:&nbsp;<?php echo (!empty($user[0]['i_firstname']) ? $user[0]['i_firstname'] : "N/A");?><span style="float:right;"><a href="#">List of your invoices</a></span><br>
                                Company name:&nbsp;<?php echo (!empty($user[0]['i_company_name'])) ? $user[0]['i_company_name'] : "N/A"?><br>
                                Town:&nbsp;<?php echo (!empty($user[0]['i_town'])) ? $user[0]['i_town'] : "N/A";?><br>
                                Zip-Code:&nbsp;<?php echo (!empty($user[0]['i_zip_code'])) ? $user[0]['i_zip_code'] : "N/A"; ?><br><span style="float:right;"><a style="cursor:pointer;" onclick="popups_ajax('account_settings','3')" href="javascript:void(0);"><img src="<?php echo base_url(); ?>assets/img/edit.png"></a></span>
                               <?php //country
								$country_id = !empty($user[0]['i_country']) ? $user[0]['i_country'] : "";
								if(!empty($country_id)){
								$country = $this->user_model->get_countries_by_id($country_id);
								$country = $country[0]['country_name'];
								}else{
									$country = "N/A";
									}
								?>	
                                Country:&nbsp;<?php echo $country;?>
                            </div>
                            </div> 
                            
                            <div class="login_profile">
                            <div class="accountsetting_title">Your account</div>
                            <div><label>Your Status:</label><?php echo $type_of_membership; ?> <a href="#">(Go Premium!)</a></div>
                            <div><label>Date of registration:</label><?php echo date('j, F Y',strtotime($user[0]['date_of_registration']) )?></div>
                            <div><label>End of Term:</label>Your account is valid for an unlimite period of time.</div>
                            <div><label>Cancel account:</label><a href="#">Please click to cancel account.</a></div>
                            </div> 
                    	</div>
                    </section>
                </div>

            </section>

            <?php include_once("includes/sidebars/newsletter_sidebar.php");?>
        </section>
        <script type ="text/javascript">
			 //we bind only to the rateit controls within the products div
			 $('.dashreview .rateit').bind('rated reset', function (e) {
				 var ri = $(this);
		 
				 //if the use pressed reset, it will get value: 0 (to be compatible with the HTML range control), we could check if e.type == 'reset', and then set the value to  null .
				 var value = ri.rateit('value');
				 //alert(value);
				 var productID = ri.data('productid'); 
				 //var starheight = ri.rateit('starheight'); 
				 // if the product id was in some hidden field: ri.closest('li').find('input[name="productid"]').val()
					//alert(productID);
					//alert(starheight)
				 //maybe we want to disable voting?
				 ri.rateit('readonly', true);
		 
				 $.ajax({
					 url: '<?php echo site_url('newsletter/rateit');?>', //your server side script
					 data: { action:'rate', id: productID, value: value }, //our data
					 type: 'POST',
					 success: function (data) {
						 $('#response').append('<li>' + data + '</li>');
						$("#result_star").rateit('value',data);
					 },
					 error: function (jxhr, msg, err) {
						 $('#response').append('<li style="color:red">' + msg + '</li>');
					 }
				 });
			 });
		$(document).ready(
    		function(){
			 $(".rating_hover").hover(function(e){
				 if ( $(this).children(".rating_popup").is(":visible")==true) {
						$(this).children(".rating_popup").hide();
					}
					else {
						$(this).children(".rating_popup").show();
					}       
				 //$(this).next().css("display","block");
				 }
			 );
			   });
			 function display_tabs(id){
				 var num = id.split("_");
				 $(".tabs li").removeClass("current");
				 $(".section").css("display","none");
				 $("#"+id).addClass("current");
				 $("#section_"+num[1]).css("display","block");
				 }
			<?php
			if(empty($mynl_tab)){
				$mynl_tab = 'tab_1';
				}
			?>
				var mynl_tab = '<?php echo ($this->session->flashdata("flash_mynl_tab") ? $this->session->flashdata("flash_mynl_tab") : $mynl_tab); //echo $this->session->flashdata("flash_mynl_tab")?>'; 
			//alert(mynl_tab);
			if(mynl_tab == 'tab_2'){
				
				display_tabs('tab_2');
			}else if(mynl_tab =='tab_1'){
				display_tabs('tab_1');
			}else if(mynl_tab == 'tab_3'){
				display_tabs('tab_3');
			}else if(mynl_tab == 'tab_4'){
				display_tabs('tab_4');
			}else{
				display_tabs('tab_1');
			}
			function schedule_set(id,loc){
			if(loc == 'site' ){
				
				if(id == 'Daily'){
					$(".site .everyweekson").find("input").attr('disabled',false);every
					$('.site input[name="weeks_on[]"]').attr('checked', false);
					$('.site input[name="every"]').attr('disabled', true);
					$('.site input[name="every"]').val('');
					//$('.site input[name="weeks_on[]"]').attr('checked', 'checked');
					$('.site input[name="weeks_on[]"]').attr('disabled', true);
					
					
				}else if(id == 'Weekly'){
					$(".site .everyweekson").find("input").attr('disabled',false);
					//$('.site input[name="weeks_on[]"]').attr('checked', false);
					$('.site input[name="every"]').attr('disabled', true);
					//$('input[name="weeks_on"]').attr('disabled', true);
				}else if(id == 'Monthly'){
					$(".site .everyweekson").find("input").attr('disabled',false);
					//$('.site input[name="weeks_on[]"]').attr('checked', false);
					//$('input[name="every"]').attr('disabled', true);
					//$('input[name="weeks_on"]').attr('disabled', true);
				}else if(id == 'Yearly'){
					$(".site .everyweekson").find("input").attr('disabled',false);
					//$('.site input[name="weeks_on[]"]').attr('checked', false);
					$('.site input[name="every"]').attr('disabled', true);
					$('.site input[name="every"]').val('');
					//$('.site input[name="weeks_on[]"]').attr('checked', 'checked');
					$('.site input[name="weeks_on[]"]').attr('disabled', true);
				}
			}
			if(loc == 'popup'){
				
				if(id == 'Daily'){
					$(".popup_ajax .everyweekson").find("input").attr('disabled',false);
					$('.popup_ajax input[name="weeks_on[]"]').attr('checked', false);
					$('.popup_ajax input[name="every"]').attr('disabled', true);
					$('.popup_ajax input[name="every"]').val('');
					//$('.popup_ajax input[name="weeks_on[]"]').attr('checked', 'checked');
					$('.popup_ajax input[name="weeks_on[]"]').attr('disabled', true);
					
					
				}else if(id == 'Weekly'){
					$(".popup_ajax .everyweekson").find("input").attr('disabled',false);
					//$('.popup_ajax input[name="weeks_on[]"]').attr('checked', false);
					$('.popup_ajax input[name="every"]').attr('disabled', true);
					
					//$('input[name="weeks_on"]').attr('disabled', true);
				}else if(id == 'Monthly'){
					$(".popup_ajax .everyweekson").find("input").attr('disabled',false);
					//$('.popup_ajax input[name="weeks_on[]"]').attr('checked', false);
					//$('input[name="every"]').attr('disabled', true);
					//$('input[name="weeks_on"]').attr('disabled', true);
				}else if(id == 'Yearly'){
					$(".popup_ajax .everyweekson").find("input").attr('disabled',false);
					//$('.popup_ajax input[name="weeks_on[]"]').attr('checked', false);
					$('.popup_ajax input[name="every"]').attr('disabled', true);
					$('.popup_ajax input[name="every"]').val('');
					//$('.popup_ajax input[name="weeks_on[]"]').attr('checked', 'checked');
					$('.popup_ajax input[name="weeks_on[]"]').attr('disabled', true);
				}
				}
			}
		
 		</script>
        
        <script src="<?php echo site_url('assets/js')?>/jquery.rateit.js" type="text/javascript"></script>
</main>