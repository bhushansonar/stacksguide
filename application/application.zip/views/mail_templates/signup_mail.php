<html><body><div style="font-family:Verdana, Arial, Helvetica, sans-serif; font-size:12px; margin:0; padding:0;">
<table cellspacing="0" cellpadding="0" border="0" width="100%">
	<tr>
    	<td align="center" valign="top" style="padding:20px 0 20px 0">
        	<table bgcolor="#FFFFFF" cellspacing="0" cellpadding="10" border="0" width="650" style="background:none repeat scroll 0 0 #E46C0A;">
            	<tr class="logo" style="background:#ffff; border:none;">
                	<td valign="top">
                    	<div style="background: none repeat scroll 0% 0% white; padding: 10px; position: relative;">
                    	<a style="color:#FFFFFF; font-size:26px;" href="<?php echo site_url();?>" target="_blank"><img style="width:191px;" src="<?php echo site_url();?>/assets/img/logo.png"></a>
                        <span style="color: #E46C0A; font-weight: bold; display: inline-block; font-size: 20px; margin-left: 77px;">The World's Safest Newsletter Library</span>
                        </div>
                    </td>
                </tr>
                <tr>
					<td valign="top">
                    	<table cellspacing="0" cellpadding="0" border="0" width="650">
                        	<tr>
                            	<td colspan="2">
                                	<h2 style="color:#FFF;">Account Confirmation for KnewDog!</h2>
                                </td>
                            </tr>
                            <tr>
                    <td style="background-color:#FFFFFF; color:#000000; text-align:left; font-size:13px; padding:5px; font-weight:bold;" ><p style="color:#000 !important">KnewDog! has generated your new Account at <a style="color:#E46C0A;" href="<?php echo $url;?>">www.knewdog.com/confirm</a>, Please use this link to confirm your email.</p>
                     <div style="color: #E46C0A; font-weight: bold;">
                        <span style="color: #E46C0A; font-weight: bold;">Thank you for using KnewDog,</span><br/>
                        <span style="color: #E46C0A; font-weight: bold;">KnewDog Team.</span>
                    </div>
                    </td>
				</tr>
                        </table>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>
</div></body></html>
 