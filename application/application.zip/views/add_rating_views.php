<main>
<link href="<?php echo site_url('assets/css')?>/rateit.css" rel="stylesheet" type="text/css">
<div class="set_errors">
<?php
$this->load->model('newsletter_model');

 //echo validation_errors();
 if ($this->session->flashdata('form_errors')){ //change!
    echo "<div class='error'>";
    echo $this->session->flashdata('form_errors');
    echo "</div>";
    }
     if($this->session->flashdata('flash_message')){
          echo '<div class="alert '.$this->session->flashdata("flash_class").'">';
            echo '<a class="close" data-dismiss="alert">&#215;</a>';
            echo $this->session->flashdata("flash_message");
          echo '</div>';       
      }
	  //echo '<pre>'; print_r($newsletter_review); die;
	  ?>
</div>
      <section class="knewdog findnewsletter" id="container">
            <section id="knewdog_leftbar">
            	<div class="knewdog_leftbar_inner" style="width:100%;">
                	<div class="page_helptitle">
						<h2>Customers Reviews on <?php echo $newsletter[0]['newsletter_name']?></h2>
					</div>
                	 <?php 
								//$get_rate = $this->newsletter_model->get_rate_by_user($newsletter[$i]['newsletter_id']);  
									/*$total_user_rate = count($get_rate);
									$star_1 = array();
									$star_2 = array();
									$star_3 = array();
									$star_4 = array();
									$star_5 = array();
									
									for($r=0;$r<count($get_rate);$r++){
											$avg_rate[] = $get_rate[$r]['rate'];
											
											if($get_rate[$r]['rate'] <= 1)
											{
												$star_1[] = $get_rate[$r]["rate"];
											}
											else if($get_rate[$r]['rate'] <= 2)
											{
												$star_2[] = $get_rate[$r]["rate"];
											}
											else if($get_rate[$r]['rate'] <= 3)
											{
												$star_3[] = $get_rate[$r]["rate"];
											}
											else if($get_rate[$r]['rate'] <= 4)
											{
												$star_4[] = $get_rate[$r]["rate"];
											}
											else if($get_rate[$r]['rate'] <= 5)
											{
												$star_5[] = $get_rate[$r]["rate"];
											}										}
										//print_r($avg_rate);
										$s_star_1 = 	count($star_1);
										@$s_star_1_per = (100 * $s_star_1)/$total_user_rate;
										$s_star_1_per = !empty($s_star_1_per) ? $s_star_1_per : "0";
										
										$s_star_2 = 	count($star_2);
										@$s_star_2_per = (100 * $s_star_2)/$total_user_rate;
										$s_star_2_per = !empty($s_star_2_per) ? $s_star_2_per : "0";
										
										$s_star_3 = 	count($star_3);
										@$s_star_3_per = (100 * $s_star_3)/$total_user_rate;
										$s_star_3_per = !empty($s_star_3_per) ? $s_star_3_per : "0";
										
										$s_star_4 = 	count($star_4);
										@$s_star_4_per = (100 * $s_star_4)/$total_user_rate;
										$s_star_4_per = !empty($s_star_4_per) ? $s_star_4_per : "0";
										
										$s_star_5 = 	count($star_5);
										@$s_star_5_per = (100 * $s_star_5)/$total_user_rate;
										$s_star_5_per = !empty($s_star_5_per) ? $s_star_5_per : "0";
										
										$s_star_1_per = round($s_star_1_per,2);
										$s_star_2_per = round($s_star_2_per,2);
										$s_star_3_per = round($s_star_3_per,2);
										$s_star_4_per = round($s_star_4_per,2);
										$s_star_5_per = round($s_star_5_per,2);
										
										@$rate_sum = array_sum($avg_rate);
										@$avg = (float)$rate_sum/(int)$total_user_rate;
										@$avg_round = $avg;//round(2.8, 1);*/
									include("rating/rating_calculation.php");
								   include("rating/rating_view.php");
								  $user_id = $this->session->userdata("user_id"); 
									//echo "user_id->".$newsletter[$i]["user_id"];
									$wherefield =array("join_newsletter_id","join_user_id");
									$wherevalue = array($newsletter[0]["newsletter_id"],$user_id);
									$get_news_user_id = $this->newsletter_model->get_rate_by_field($wherefield,$wherevalue);
								if(!empty($user_id)){
									if(count($get_news_user_id) > 0){
											$readonly = "true";		
								    }else{
										$readonly = "false";	
										}
								}else{
										$readonly = "true";
									}
								//echo '<pre>'; print_r($get_news_user_id);
							
								
										if(count($get_news_user_id) > 0){
										$star_read_only = true;
										}else{
										
											$star_read_only = false;
											}
								//}
								   ?>
                                   <div class="starrating_detail">
                                        <div class="reviewstar">
                                            <div title="<?php echo $avg_round;?>" style="float:left; margin-top:2px;" data-productid="<?php echo $newsletter[0]['newsletter_id']; ?>" data-rateit-resetable="false" data-rateit-value="<?php echo $avg_round;?>" data-rateit-ispreset="true" data-rateit-reset="false" data-rateit-readonly="true" class="rateit" id="rateit9"></div>
                                            <a style="margin-left:3px;" href="#">(<?php echo $total_user_rate;?>)</a>
                                        </div>
                                        <div class="reviewstar"><div style="color:#808080; margin-top:5px;"><?php echo round($avg_round,2)?> Out of 5 stars</div></div>
                                        
                                    </div>
                                    <div class="add_review contact">
                              
                                     <?php 
									if(!empty($user_id)){
										
										$this->load->model('subscribe_model');
										$where_s_field = array('s_user_id','s_newsletter_id');
										$where_s_value = array($user_id,$newsletter[0]["newsletter_id"]);
										$subscribed = $this->subscribe_model->get_subscribe('', '', '', '', '',$where_s_field,$where_s_value);
										if(count($subscribed) > 0){
											
											
									
										 if($get_news_user_id != true){?>
                                    	<div id="content" style="width:70%;">
                                       
                                       <h1>-- -- -- Add review -- -- --</h1>
                                        
                                        <form id="form_rate" action="<?php echo site_url("newsletter/addreview")?>" method="post" autocomplete="on">
                                                <input type="hidden" id="rate" name="rate" value="" />
                                                <input type="hidden" name="join_user_id" value="<?php echo $this->session->userdata("user_id")?>" />		
                                                <input type="hidden" name="join_newsletter_id" value="<?php echo $newsletter[0]["newsletter_id"]?>" />		
                                                
                                            <div><label for="subject" class="iconic quote-alt"> Rate  <span class="required">*</span></label> 
                                            <div style="  width:210px; padding:10px; padding-top: 3px; padding-bottom: 13px;" data-productid="<?php echo $newsletter[0]['newsletter_id']; ?>" data-rateit-resetable="false" data-rateit-value="0" data-rateit-ispreset="true" data-rateit-reset="false" data-rateit-readonly="false" class="rateit" id="rateit9"></div> </div>
                                
                                            <p> <label for="subject" class="iconic quote-alt"> Title  <span class="required">*</span></label> <input type="text" name="title" id="title"  placeholder="What would you like to talk about?"> </p>
                                
                                            <p> <label for="message" class="iconic comment"> Message  <span class="required">*</span></label> <textarea placeholder="Don't be shy, leave a review " name="message" ></textarea> </p>
                                            <p class="indication"> All fields with a <span class="required">*</span> are required</p>
                                            
                                            <input onclick="" type="submit" value=" ★ SUBMIT" class="button">		
                                
                                        </form>		
                                       
                                    </div>
                                     <?php }else{?>
                                        <h1 style="clear: both; color: rgb(228, 108, 10); text-align: center;">You have already rated for this Newsletter!</h1>
                                        <?php }
										}else{
										
										echo '<h1 style="clear: both; color: rgb(228, 108, 10); text-align: center;">Please subscribe to this newsletter to add review!</h1>';
											}
									}else{
										?>
                                    
        <h1 style="clear: both; color: rgb(228, 108, 10); text-align: center;">Please <a style="cursor:pointer;" onclick="popup('signin')">Login</a> to add review!</h1>  
                                    <?php }?>
    	
                                    </div>
                                    <article>
                               <?php 
							   if(count($newsletter_review) > 0){
							   for($i=0;$i<count($newsletter_review);$i++){
								   ?>
                            	<div class="fullwidth_left details mostrecentreviews">
                                        <div class="minititle">
                                            <div title="<?php echo $newsletter_review[$i]['rate'];?>" style="float:left;" data-productid="<?php echo $newsletter_review[$i]['join_newsletter_id']; ?>" data-rateit-resetable="false" data-rateit-value="<?php echo $newsletter_review[$i]['rate'];?>" data-rateit-ispreset="true" data-rateit-reset="false" data-rateit-readonly="true" class="rateit" id="rateit9"></div>
                                            <label><?php echo $newsletter_review[$i]["title"]?></label>
                                        </div>
                                        <div class="description"><?php echo $newsletter_review[$i]["message"]?></div>
                                        <span>Published on <?php echo @date('j, F Y',strtotime($newsletter_review[$i]['date']));?> by <?php echo $newsletter_review[$i]["firstname"]?></span>
                                </div>
                                <?php }
							   }
							   ?>
                               <?php echo '<div class="pagination">'.$this->pagination->create_links().'</div>'; ?> 
                            </article>
                
                </div>
            </section>
            <?php include_once("includes/sidebars/newsletter_sidebar.php");?>
            <script type="text/javascript">
             $('#form_rate .rateit').bind('rated reset', function (e) {
				 var ri = $(this);
		 
				 //if the use pressed reset, it will get value: 0 (to be compatible with the HTML range control), we could check if e.type == 'reset', and then set the value to  null .
				 var value = ri.rateit('value');
				 $("#rate").val(value);
				 //alert(value);
				 var productID = ri.data('productid'); 
				 //var starheight = ri.rateit('starheight'); 
				 // if the product id was in some hidden field: ri.closest('li').find('input[name="productid"]').val()
					//alert(productID);
					//alert(starheight)
				 //maybe we want to disable voting?
				 ri.rateit('readonly', true);
		 
				 $.ajax({
					 url: '<?php echo site_url('newsletter/rateit');?>', //your server side script
					 data: { action:'rate', id: productID, value: value }, //our data
					 type: 'POST',
					 success: function (data) {
						 $('#response').append('<li>' + data + '</li>');
						$("#result_star").rateit('value',data);
					 },
					 error: function (jxhr, msg, err) {
						 $('#response').append('<li style="color:red">' + msg + '</li>');
					 }
				 });
			 });
            </script>
            <script src="<?php echo site_url('assets/js')?>/jquery.rateit.js" type="text/javascript"></script>
      </section>