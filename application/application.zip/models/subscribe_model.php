<?php
class Subscribe_model extends CI_Model {
    /**
    * Responsable for auto load the database
    * @return void
    */
    public function __construct()
    {
        $this->load->database();
    }

    /**
    * Get product by his is
    * @param int $product_id 
    * @return array
    */
    public function get_subscribe_by_id($id)
    {
		$this->db->select('*');
		$this->db->from('subscribe');
		$this->db->where('subscribe_id', $id);
		$query = $this->db->get();
		return $query->result_array(); 
    }    

    /**
    * Fetch subscribe data from the database
    * possibility to mix search, filter and order
    * @param string $search_string 
    * @param strong $order
    * @param string $order_type 
    * @param int $limit_start
    * @param int $limit_end
    * @return array
    */
    public function get_subscribe($search_string=null, $order=null, $order_type='DESC', $limit_start=null, $limit_end=null,$wherefield=array(),$wherevalue=array())
    {
	    
		$this->db->select('*');
		$this->db->from('subscribe');
		
		if(count($wherefield) > 0){
			for($i=0;$i<count($wherefield);$i++){
			$this->db->where($wherefield[$i],$wherevalue[$i]);
			}
			}
		//$this->db->order_by('status', 'Active');

		if($search_string){
			$this->db->like($order, $search_string);
		}
		$this->db->group_by('subscribe_id');

		if($order){
			$this->db->order_by($order, $order_type);
		}else{
		    $this->db->order_by('subscribe_id', $order_type);
		}

        if($limit_start && $limit_end){
          $this->db->limit($limit_start, $limit_end);	
        }

        if($limit_start != null){
          $this->db->limit($limit_start, $limit_end);    
        }
        
		$query = $this->db->get();
		
		return $query->result_array(); 	
    }

    /**
    * Count the number of rows
    * @param int $search_string
    * @param int $order
    * @return int
    */
    function count_subscribe($search_string=null, $order=null)
    {
		$this->db->select('*');
		$this->db->from('subscribe');
		//$this->db->where('status', 'Active');
		if($search_string){
			$this->db->like($order, $search_string);
		}
		if($order){
			$this->db->order_by($order, 'Asc');
		}else{
		    $this->db->order_by('subscribe_id', 'Asc');
		}
		$query = $this->db->get();
		return $query->num_rows();        
    }

    /**
    * Store the new item into the database
    * @param array $data - associative array with data to store
    * @return boolean 
    */
    function store_subscribe($data)
    {
		$insert = $this->db->insert('subscribe', $data);
	    return $insert;
	}

    /**
    * Update subscribe
    * @param array $data - associative array with data to store
    * @return boolean
    */
    function update_subscribe($id, $data)
    {
		$this->db->where('subscribe_id', $id);
		$this->db->update('subscribe', $data);
		$report = array();
		$report['error'] = $this->db->_error_number();
		$report['message'] = $this->db->_error_message();
		if($report !== 0){
			return true;
		}else{
			return false;
		}
	}
	
	function update_subscribe_with_user_id_nl_id($id_field=array(),$id_value=array(), $data=array())
    {
		if(count($id_field) > 0){
			for($i=0;$i<count($id_field);$i++){
			$this->db->where($id_field[$i],$id_value[$i]);
			}
		}
		//$this->db->where('subscribe_id', $id);
		$this->db->update('subscribe', $data);
		$report = array();
		$report['error'] = $this->db->_error_number();
		$report['message'] = $this->db->_error_message();
		if($report !== 0){
			return true;
		}else{
			return false;
		}
	}

    /**
    * Delete subscriber
    * @param int $id - subscribe id
    * @return boolean
    */
	function delete_subscribe($id){
		$this->db->where('subscribe_id', $id);
		$this->db->delete('subscribe'); 
	}
	
	function delete_subscribe_with_userid_newsletterid($user_id,$newsletter_id){
		$this->db->where('s_user_id', $user_id);
		$this->db->where('s_newsletter_id', $newsletter_id);
		$this->db->delete('subscribe'); 
	}
 
}
?>