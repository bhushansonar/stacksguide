<?php
$lang['is_unique'] = "The %s must contain a unique value.";
//$lang['edit_unique'] = "The %s must contain a unique value.";