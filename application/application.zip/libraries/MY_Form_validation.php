<?php
class MY_Form_validation extends CI_Form_validation {

    public function __construct() {
        parent::__construct();
    }

    public function is_unique($str, $field) {
	//echo "hi"; die;
        $field_ar = explode('.', $field);
        $query = $this->CI->db->get_where($field_ar[0], array($field_ar[1] => $str), 1, 0);
		//echo '<pre>'; print_r($query->num_rows()); die;
		//$this->CI->form_validation->set_message($field,'That %s already exists.');
        if ($query->num_rows() === 0) {
            return TRUE;
        }
		
        return FALSE;
    }
	
	/*public function is_unique_update($str, $field) {
	
	
        $field_ar = explode('.', $field);
		
		$this->CI->db->select('*');
		$this->CI->db->from($field_ar[0]);
		$this->CI->db->where($field_ar[1], $str);
     	$query = $this->CI->db->get();
		
		//$this->db->where('language_shortcode',$key);
		//$query = $this->db->get('language');
		//echo '<pre>'; print_r($query->result_array());
		$id = $this->CI->uri->segment(4);
		$get_keys = $query->result_array();
		$first_id = array_keys($get_keys[0]);
		$main_id = $query->result_array()[0][$first_id[0]];
	   //$query = $this->CI->db->get_where($field_ar[0], array($field_ar[1] => $str), 1, 0);
		//echo '<pre>'; print_r($query); die;
		//echo $id ."==". $main_id[0]; die;
		if($id == $main_id[0]){
			return FALSE;
		}else{
			$this->is_unique($str, $field);
		}
        if ($query->num_rows() === 0) {
            return TRUE;
        }
        return FALSE;
    }*/
	function edit_unique($value, $params) 
	{
		$CI =& get_instance();
		$CI->load->database();
	
		$CI->form_validation->set_message('edit_unique', "Sorry, that %s is already being used.");
	
		list($table, $field, $current_id) = explode(".", $params);
	
		$query = $CI->db->select()->from($table)->where($field, $value)->limit(1)->get();
		$array = json_decode(json_encode($query->row()), true);
		$first_id = array_keys($array);
		if ($query->row() && $query->row()->$first_id[0] != $current_id)
		{
			return FALSE;
		}
	}
	
	 function valid_url($str){
		/*if(filter_var($str, FILTER_VALIDATE_URL, FILTER_FLAG_HOST_REQUIRED) == TRUE){
			return TRUE;
	 }else{
		 return FALSE;
		 }*/
           //$pattern = "/^(http|https|ftp):\/\/([A-Z0-9][A-Z0-9_-]*(?:\.[A-Z0-9][A-Z0-9_-]*)+):?(\d+)?\/?/i";
		 // $pattern = "|^http(s)?://[a-z0-9-]+(.[a-z0-9-]+)*(:[0-9]+)?(/.*)?$|i";
		   /*$pattern = "/(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/";
            if (!preg_match($pattern, $str))
            {
                return FALSE;
            }

            return TRUE;*/
			$ch = @curl_init($str);
			@curl_setopt($ch, CURLOPT_HEADER, TRUE);
			@curl_setopt($ch, CURLOPT_NOBODY, TRUE);
			@curl_setopt($ch, CURLOPT_FOLLOWLOCATION, FALSE);
			@curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
			$status = array();
			preg_match('/HTTP\/.* ([0-9]+) .*/', @curl_exec($ch) , $status);
			//echo '<pre>'; print_r(curl_exec($ch)); die;
			if(@$status[1] == 200)
			{
				return TRUE;
			}else{
				return FALSE;
				}
				
				
    }
	
	/*   $field is the field you're setting
 *   $value is the "selected" value from the previous form post
 *   $defaults is an object containing defaults in case the form is being used to create a new record. It could be filled with null values, or actual default values if you need that. 
 */

	/*function validateImage($field) {
        if($_FILES[$field]['size'] == 0) {
            $this->form_validation->set_message($field, 'You did not upload an image.');
            return FALSE;
        } else {
            return TRUE;
        }
	} */
	function check_min_max($input, $min, $max)
	{
		$length = ($input);
	
		if ($length <= $max && $length >= $min)
		{
			return TRUE;
		}
		elseif ($length < $min)
		{
			$this->form_validation->set_message('check_length', 'Minimum number is ' . $min);
			return FALSE;        
		}
		elseif ($length > $max)
		{
			$this->form_validation->set_message('check_length', 'Maximum number is ' . $max);
			return FALSE;        
		}
	}
	
	function password_matches($submitted_value, $admin_id)
		{
			$CI =& get_instance();
			$CI->load->database();
			$CI->load->model('user_model');
			$get_user = $CI->user_model->get_user_by_id($admin_id);
			$old_type_pass_field = md5($submitted_value);
			$old_db_password = $get_user[0]['password'];
		  //load your admin by id, validate current password.
		  if ($old_db_password != $old_type_pass_field)
		  {
			$CI->form_validation->set_message('password_matches', 'The password you supplied does not match your existing password.');
			return FALSE;
		  }
		
		  //passed...
		  return TRUE;
		} 
}